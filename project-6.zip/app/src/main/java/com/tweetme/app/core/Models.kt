package com.tweetme.app.core

/** عضو في التطبيق. */
data class User(
    val uid: String,
    val name: String,
    val username: String,
    val about: String = "",
    /** صورة الملف الشخصي كنص data URI صغير، أو فارغ إن لم توجد. */
    val photo: String = "",
    val lastSeen: Long = 0L,
    val showLastSeen: Boolean = true,
    val showReceipts: Boolean = true
) {
    /** متصل الآن: آخر نبضة حضور خلال دقيقة وربع. */
    fun isOnline(now: Long): Boolean = showLastSeen && lastSeen > 0 && now - lastSeen < 75_000
}

/** نوع الرسالة. القيمة النصية wire هي ما يُخزَّن في Firestore. */
enum class MsgType(val wire: String) {
    TEXT("text"), IMAGE("image"), VOICE("voice");

    companion object {
        fun from(s: String?): MsgType = entries.firstOrNull { it.wire == s } ?: TEXT
    }
}

/** علامات تُخزَّن في نص الرد حين تكون الرسالة المردود عليها صورة أو صوتاً. */
const val REPLY_IMAGE = "\u0001img"
const val REPLY_VOICE = "\u0001voice"

/** رسالة داخل محادثة. url تحمل الصورة أو الصوت (data URI) عند الحاجة. */
data class Message(
    val id: String,
    val from: String,
    val type: MsgType,
    val text: String,
    val url: String,
    val durSec: Int,
    val at: Long,
    val pending: Boolean = false,
    val replyToId: String = "",
    val replyText: String = "",
    val replyFrom: String = "",
    val deleted: Boolean = false,
    val edited: Boolean = false,
    /** تفاعلات الأعضاء: uid ← إيموجي. */
    val reactions: Map<String, String> = emptyMap(),
    /** أعضاء حذفوا الرسالة عندهم فقط. */
    val hiddenFor: List<String> = emptyList()
)

/** أعلام المحادثة الخاصة بكل عضو. */
enum class ChatFlag(val key: String) { PINNED("pinned"), ARCHIVED("archived"), MUTED("muted") }

/** ملخص محادثة لقائمة المحادثات. */
data class ChatSummary(
    val id: String,
    val peerUid: String,
    val lastType: MsgType,
    val lastText: String,
    val lastFrom: String,
    val updatedAt: Long,
    val unread: Int,
    val peerReadAt: Long,
    val pinned: Boolean = false,
    val archived: Boolean = false,
    val muted: Boolean = false,
    val peerTypingAt: Long = 0L
)

/** مسودة رسالة قبل الإرسال. */
data class Draft(
    val type: MsgType,
    val text: String = "",
    val url: String = "",
    val durSec: Int = 0,
    val replyToId: String = "",
    val replyText: String = "",
    val replyFrom: String = ""
)
