package com.tweetme.app.ui.settings

import android.content.Intent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Chat
import androidx.compose.material.icons.outlined.Contacts
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.Language
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.Notifications
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.outlined.Share
import androidx.compose.material.icons.outlined.Storage
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tweetme.app.R
import com.tweetme.app.core.User
import com.tweetme.app.data.ChatBackend
import com.tweetme.app.ui.common.Avatar
import com.tweetme.app.ui.common.ScreenTopBar

/** مسارات شاشات الإعدادات؛ لإضافة شاشة جديدة أضف مساراً هنا وسطر composable في AppNav. */
object SettingsRoutes {
    const val HOME = "settings"
    const val PROFILE = "settings/profile"
    const val ACCOUNT = "settings/account"
    const val CONTACTS = "contacts"
    const val PRIVACY = "settings/privacy"
    const val BLOCKED = "settings/blocked"
    const val CHATS = "settings/chats"
    const val NOTIFICATIONS = "settings/notifications"
    const val STORAGE = "settings/storage"
    const val HELP = "settings/help"
}

/** الشاشة الرئيسية للإعدادات: بطاقة الملف الشخصي وقائمة الأقسام بأسلوب واتساب. */
@Composable
fun SettingsScreen(me: User, backend: ChatBackend, onNavigate: (String) -> Unit) {
    val ctx = LocalContext.current
    var confirmLogout by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize()) {
        ScreenTopBar(AnnotatedString(stringResource(R.string.tab_settings)))
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(bottom = 24.dp)) {
            Row(
                Modifier.fillMaxWidth().clickable { onNavigate(SettingsRoutes.PROFILE) }.padding(horizontal = 18.dp, vertical = 16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Avatar(me, 64.dp)
                Column(Modifier.weight(1f)) {
                    Text(me.name, fontWeight = FontWeight.Bold, fontSize = 18.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(
                        me.about.ifBlank { stringResource(R.string.about_default) },
                        color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 14.sp,
                        maxLines = 1, overflow = TextOverflow.Ellipsis
                    )
                }
            }
            HorizontalDivider(color = MaterialTheme.colorScheme.outline)

            SettingRow(Icons.Outlined.Contacts, R.string.contacts, R.string.contacts_hint) { onNavigate(SettingsRoutes.CONTACTS) }
            SettingRow(Icons.Outlined.Person, R.string.set_account, R.string.set_account_hint) { onNavigate(SettingsRoutes.ACCOUNT) }
            SettingRow(Icons.Outlined.Lock, R.string.set_privacy, R.string.set_privacy_hint) { onNavigate(SettingsRoutes.PRIVACY) }
            SettingRow(Icons.Outlined.Chat, R.string.set_chats, R.string.set_chats_hint) { onNavigate(SettingsRoutes.CHATS) }
            SettingRow(Icons.Outlined.Notifications, R.string.set_notifications, R.string.set_notifications_hint) { onNavigate(SettingsRoutes.NOTIFICATIONS) }
            SettingRow(Icons.Outlined.Storage, R.string.set_storage, R.string.set_storage_hint) { onNavigate(SettingsRoutes.STORAGE) }
            SettingRow(Icons.Outlined.Language, R.string.set_language, R.string.set_language_hint)
            SettingRow(Icons.Outlined.Info, R.string.set_help, R.string.set_help_hint) { onNavigate(SettingsRoutes.HELP) }
            SettingRow(Icons.Outlined.Share, R.string.set_invite, R.string.set_invite_hint) {
                val send = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_TEXT, ctx.getString(R.string.invite_text))
                }
                ctx.startActivity(Intent.createChooser(send, ctx.getString(R.string.set_invite)))
            }

            if (backend.isDemo) {
                Text(
                    stringResource(R.string.demo_note),
                    color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp,
                    modifier = Modifier.padding(horizontal = 18.dp, vertical = 12.dp)
                )
            }
            Button(
                onClick = { confirmLogout = true },
                modifier = Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 8.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.error,
                    contentColor = MaterialTheme.colorScheme.onError
                )
            ) { Text(stringResource(R.string.logout)) }
            Text(
                stringResource(R.string.version_label),
                color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp,
                modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                textAlign = androidx.compose.ui.text.style.TextAlign.Center
            )
        }
    }

    if (confirmLogout) {
        AlertDialog(
            onDismissRequest = { confirmLogout = false },
            title = { Text(stringResource(R.string.logout_confirm)) },
            confirmButton = {
                TextButton(onClick = { confirmLogout = false; backend.signOut() }) { Text(stringResource(R.string.logout)) }
            },
            dismissButton = { TextButton(onClick = { confirmLogout = false }) { Text(stringResource(R.string.cancel)) } }
        )
    }
}
