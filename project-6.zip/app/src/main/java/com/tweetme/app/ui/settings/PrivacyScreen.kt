package com.tweetme.app.ui.settings

import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Block
import com.tweetme.app.R
import com.tweetme.app.core.User
import com.tweetme.app.core.errorKind
import com.tweetme.app.core.errorRes
import com.tweetme.app.data.ChatBackend
import com.tweetme.app.ui.common.Avatar
import com.tweetme.app.ui.common.SubTopBar
import kotlinx.coroutines.launch

/** الخصوصية: آخر ظهور وإيصالات القراءة والمحظورون. */
@Composable
fun PrivacyScreen(
    me: User, backend: ChatBackend, prefs: com.tweetme.app.data.AppPrefs, store: com.tweetme.app.data.PrefsStore,
    onBack: () -> Unit, onBlocked: () -> Unit
) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()

    fun save(lastSeen: Boolean, receipts: Boolean) {
        scope.launch {
            try {
                backend.setPrivacy(me.uid, lastSeen, receipts)
            } catch (e: Exception) {
                Toast.makeText(ctx, errorRes(e.errorKind()), Toast.LENGTH_SHORT).show()
            }
        }
    }

    Column(Modifier.fillMaxSize()) {
        SubTopBar(stringResource(R.string.set_privacy), onBack)
        Column(Modifier.weight(1f)) {
            SectionTitle(R.string.priv_who_sees)
            SwitchRow(R.string.priv_last_seen, R.string.priv_last_seen_hint, me.showLastSeen) { save(it, me.showReceipts) }
            SwitchRow(R.string.priv_receipts, R.string.priv_receipts_hint, me.showReceipts) { save(me.showLastSeen, it) }
            SectionTitle(R.string.priv_security)
            SwitchRow(R.string.priv_secure, R.string.priv_secure_hint, prefs.secureScreen) { scope.launch { store.setSecureScreen(it) } }
            SectionTitle(R.string.priv_contacts)
            SettingRow(Icons.Outlined.Block, R.string.priv_blocked, R.string.priv_blocked_hint, onBlocked)
            Text(
                stringResource(R.string.priv_note),
                color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp,
                modifier = Modifier.padding(horizontal = 18.dp, vertical = 16.dp)
            )
        }
    }
}

/** قائمة المحظورين مع زر إلغاء الحظر. */
@Composable
fun BlockedScreen(me: User, backend: ChatBackend, onBack: () -> Unit) {
    val scope = rememberCoroutineScope()
    val ids by backend.blocked(me.uid).collectAsState(initial = emptySet())

    Column(Modifier.fillMaxSize()) {
        SubTopBar(stringResource(R.string.priv_blocked), onBack)
        if (ids.isEmpty()) {
            Text(
                stringResource(R.string.no_blocked),
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(24.dp)
            )
        } else {
            LazyColumn(Modifier.weight(1f)) {
                items(ids.toList(), key = { it }) { uid ->
                    val user by produceState<User?>(null, uid) {
                        value = runCatching { backend.getUser(uid) }.getOrNull()
                    }
                    Row(
                        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Avatar(user, 44.dp)
                        Column(Modifier.weight(1f)) {
                            Text(user?.name ?: "…", fontWeight = FontWeight.SemiBold)
                            if (!user?.username.isNullOrEmpty()) {
                                Text("@${user?.username}", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
                            }
                        }
                        OutlinedButton(onClick = { scope.launch { runCatching { backend.unblock(me.uid, uid) } } }) {
                            Text(stringResource(R.string.unblock))
                        }
                    }
                }
            }
        }
    }
}
