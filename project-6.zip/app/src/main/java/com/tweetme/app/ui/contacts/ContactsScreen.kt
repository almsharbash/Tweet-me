package com.tweetme.app.ui.contacts

import android.content.Intent
import android.widget.Toast
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.PersonAdd
import androidx.compose.material.icons.outlined.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tweetme.app.R
import com.tweetme.app.core.User
import com.tweetme.app.core.errorKind
import com.tweetme.app.core.errorRes
import com.tweetme.app.data.ChatBackend
import com.tweetme.app.ui.common.Avatar
import com.tweetme.app.ui.common.SubTopBar
import kotlinx.coroutines.launch

/** جهات الاتصال: قائمة من أضفتهم، بحث، إضافة باسم المستخدم، وفتح محادثة بضغطة. */
@Composable
fun ContactsScreen(me: User, backend: ChatBackend, onBack: () -> Unit, onOpenChat: (String) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val ids by backend.contacts(me.uid).collectAsState(initial = emptySet())
    var query by remember { mutableStateOf("") }
    var showAdd by remember { mutableStateOf(false) }

    // تحميل ملفات الأعضاء مرة لكل تغيّر في القائمة
    val loaded by produceState<List<User>?>(null, ids) {
        value = ids.mapNotNull { runCatching { backend.getUser(it) }.getOrNull() }
            .sortedBy { it.name.lowercase() }
    }
    val q = query.trim()
    val shown = loaded.orEmpty().filter {
        q.isEmpty() || it.name.contains(q, ignoreCase = true) || it.username.contains(q, ignoreCase = true)
    }

    Column(Modifier.fillMaxSize()) {
        SubTopBar(stringResource(R.string.contacts), onBack)
        OutlinedTextField(
            value = query, onValueChange = { query = it },
            placeholder = { Text(stringResource(R.string.search_contacts)) },
            leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
            singleLine = true,
            shape = RoundedCornerShape(24.dp),
            modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 6.dp)
        )
        LazyColumn(Modifier.weight(1f)) {
            item(key = "add") {
                ActionRow(Icons.Outlined.PersonAdd, R.string.contact_add) { showAdd = true }
            }
            item(key = "invite") {
                ActionRow(Icons.Outlined.Share, R.string.set_invite) {
                    val send = Intent(Intent.ACTION_SEND).apply {
                        type = "text/plain"
                        putExtra(Intent.EXTRA_TEXT, ctx.getString(R.string.invite_text))
                    }
                    ctx.startActivity(Intent.createChooser(send, ctx.getString(R.string.set_invite)))
                }
            }
            item(key = "header") {
                Text(
                    stringResource(R.string.contacts_count, ids.size),
                    color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp, fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp)
                )
            }
            items(shown, key = { it.uid }) { u ->
                Row(
                    Modifier.fillMaxWidth().clickable { onOpenChat(u.uid) }.padding(horizontal = 16.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Avatar(u, 48.dp)
                    Column(Modifier.weight(1f)) {
                        Text(u.name, fontWeight = FontWeight.SemiBold, fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(
                            u.about.ifBlank { "@" + u.username },
                            color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp,
                            maxLines = 1, overflow = TextOverflow.Ellipsis
                        )
                    }
                    IconButton(onClick = { scope.launch { runCatching { backend.removeContact(me.uid, u.uid) } } }) {
                        Icon(Icons.Outlined.Delete, contentDescription = stringResource(R.string.contact_remove))
                    }
                }
                HorizontalDivider(
                    modifier = Modifier.padding(start = 78.dp),
                    color = MaterialTheme.colorScheme.outline.copy(alpha = 0.6f)
                )
            }
            if (loaded == null && ids.isNotEmpty()) {
                item(key = "loading") {
                    Row(Modifier.fillMaxWidth().padding(24.dp), horizontalArrangement = Arrangement.Center) {
                        CircularProgressIndicator()
                    }
                }
            } else if (ids.isEmpty()) {
                item(key = "empty") {
                    Text(
                        stringResource(R.string.contacts_empty),
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(24.dp)
                    )
                }
            }
        }
    }

    if (showAdd) {
        AddContactDialog(
            backend = backend, me = me.uid, existing = ids,
            onDismiss = { showAdd = false },
            onAdded = { showAdd = false; Toast.makeText(ctx, R.string.contact_added, Toast.LENGTH_SHORT).show() }
        )
    }
}

@Composable
private fun ActionRow(icon: androidx.compose.ui.graphics.vector.ImageVector, label: Int, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 18.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
        Text(stringResource(label), fontSize = 16.sp)
    }
}

@Composable
private fun AddContactDialog(
    backend: ChatBackend, me: String, existing: Set<String>,
    onDismiss: () -> Unit, onAdded: () -> Unit
) {
    val scope = rememberCoroutineScope()
    var username by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<Int?>(null) }

    fun add() {
        val name = username.trim().removePrefix("@").lowercase()
        if (name.isEmpty()) return
        scope.launch {
            busy = true
            error = null
            try {
                val u = backend.findUser(name)
                when {
                    u == null -> error = R.string.user_not_found
                    u.uid == me -> error = R.string.that_is_you
                    u.uid in existing -> error = R.string.contact_exists
                    else -> {
                        backend.addContact(me, u.uid)
                        onAdded()
                    }
                }
            } catch (e: Exception) {
                error = errorRes(e.errorKind())
            }
            busy = false
        }
    }

    AlertDialog(
        onDismissRequest = { if (!busy) onDismiss() },
        title = { Text(stringResource(R.string.contact_add)) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = username, onValueChange = { username = it; error = null },
                    label = { Text(stringResource(R.string.friend_username)) },
                    singleLine = true,
                    textStyle = MaterialTheme.typography.bodyLarge.copy(textDirection = TextDirection.Ltr),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Ascii)
                )
                error?.let { Text(stringResource(it), color = MaterialTheme.colorScheme.error, fontSize = 13.sp) }
            }
        },
        confirmButton = {
            TextButton(enabled = !busy && username.isNotBlank(), onClick = { add() }) {
                Text(stringResource(R.string.contact_add_btn))
            }
        },
        dismissButton = { TextButton(enabled = !busy, onClick = onDismiss) { Text(stringResource(R.string.cancel)) } }
    )
}
