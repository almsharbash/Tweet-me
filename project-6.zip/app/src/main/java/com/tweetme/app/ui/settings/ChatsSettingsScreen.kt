package com.tweetme.app.ui.settings

import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Image
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tweetme.app.R
import com.tweetme.app.data.AppPrefs
import com.tweetme.app.data.PrefsStore
import com.tweetme.app.data.ThemeMode
import com.tweetme.app.media.MediaUtils
import com.tweetme.app.ui.chat.ChatBackground
import com.tweetme.app.ui.common.SubTopBar
import com.tweetme.app.ui.theme.BG_IMAGE_ID
import com.tweetme.app.ui.theme.chatBackgrounds
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** ألوان التطبيق الجاهزة؛ أضف لوناً بإضافة رقمه هنا. */
private val ACCENTS = listOf(
    0xFF2F7BFFL, 0xFF0A84FFL, 0xFF1E5BD8L, 0xFF00B4D8L, 0xFF3B5BDBL,
    0xFF7C4DFFL, 0xFF00C389L, 0xFFFF6B6BL, 0xFFF59F00L, 0xFFD6336CL
)
private val BUBBLES = listOf(0xFF1E5BD8L, 0xFF00A884L, 0xFF7C4DFFL, 0xFFD6336CL, 0xFF111827L, 0xFFF59F00L)

/** الدردشات: السمة واللون وحجم الخط والخلفية ولون الفقاعات وزر الإدخال. */
@Composable
fun ChatsSettingsScreen(prefs: AppPrefs, store: PrefsStore, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var fontScale by remember { mutableFloatStateOf(prefs.fontScale) }
    var dialog by remember { mutableStateOf<String?>(null) }

    val bgPicker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) {
            scope.launch {
                val ok = withContext(Dispatchers.IO) { MediaUtils.saveChatBackground(ctx, uri) }
                if (ok) store.setBackground(BG_IMAGE_ID)
                else Toast.makeText(ctx, R.string.err_bg, Toast.LENGTH_SHORT).show()
            }
        }
    }

    Column(Modifier.fillMaxSize()) {
        SubTopBar(stringResource(R.string.set_chats), onBack)
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(bottom = 24.dp)) {

            SectionTitle(R.string.sec_appearance)
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                listOf(
                    ThemeMode.DARK to R.string.mode_dark,
                    ThemeMode.LIGHT to R.string.mode_light,
                    ThemeMode.AUTO to R.string.mode_auto
                ).forEach { (mode, label) ->
                    Pill(stringResource(label), prefs.mode == mode, Modifier.weight(1f)) {
                        scope.launch { store.setMode(mode) }
                    }
                }
            }
            ColorRow(R.string.app_color, prefs.accent) { dialog = "accent" }
            Column(Modifier.padding(horizontal = 18.dp, vertical = 6.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(stringResource(R.string.font_size), fontSize = 16.sp, modifier = Modifier.weight(1f))
                    Text(
                        String.format(java.util.Locale.US, "%.0f%%", fontScale * 100),
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Slider(
                    value = fontScale,
                    onValueChange = { fontScale = it },
                    onValueChangeFinished = { scope.launch { store.setFontScale(fontScale) } },
                    valueRange = 0.85f..1.3f
                )
            }

            SectionTitle(R.string.sec_chat)
            Column(Modifier.padding(horizontal = 18.dp, vertical = 6.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                ChatBackground(prefs, Modifier.fillMaxWidth().height(96.dp).clip(RoundedCornerShape(12.dp))) {
                    Column(
                        Modifier.fillMaxSize().padding(10.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp, Alignment.CenterVertically)
                    ) {
                        PreviewBubble(stringResource(R.string.preview_in), mine = false, prefs = prefs)
                        PreviewBubble(stringResource(R.string.preview_out), mine = true, prefs = prefs)
                    }
                }
            }
            SettingRow(Icons.Outlined.Image, R.string.chat_background, R.string.chat_background_hint) { dialog = "wallpaper" }
            ColorRow(R.string.bubble_color, if (prefs.bubble != 0L) prefs.bubble else prefs.accent) { dialog = "bubble" }

            SectionTitle(R.string.sec_chat_settings)
            SwitchRow(R.string.enter_sends, R.string.enter_sends_hint, prefs.enterSends) {
                scope.launch { store.setEnterSends(it) }
            }
        }
    }

    when (dialog) {
        "accent" -> ColorPickerDialog(
            title = R.string.app_color, colors = ACCENTS, selected = prefs.accent,
            onPick = { c -> scope.launch { store.setAccent(c) } },
            onDismiss = { dialog = null }
        )
        "bubble" -> ColorPickerDialog(
            title = R.string.bubble_color, colors = BUBBLES, selected = prefs.bubble, defaultColor = prefs.accent,
            onPick = { c -> scope.launch { store.setBubble(c) } },
            onDismiss = { dialog = null }
        )
        "wallpaper" -> WallpaperDialog(
            selected = prefs.bgId,
            onPick = { id -> scope.launch { store.setBackground(id) }; dialog = null },
            onGallery = {
                dialog = null
                bgPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
            },
            onDismiss = { dialog = null }
        )
    }
}

/** نافذة اختيار خلفية المحادثة: خلفيات جاهزة أو صورة من المعرض. */
@Composable
private fun WallpaperDialog(selected: String, onPick: (String) -> Unit, onGallery: () -> Unit, onDismiss: () -> Unit) {
    val shape = RoundedCornerShape(12.dp)
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.chat_background)) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                chatBackgrounds.chunked(4).forEach { row ->
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        row.forEach { bg ->
                            val on = selected == bg.id
                            val fill = if (bg.brush != null) Modifier.background(bg.brush)
                            else Modifier.background(MaterialTheme.colorScheme.surfaceVariant)
                            Box(
                                Modifier.size(56.dp).clip(shape).then(fill)
                                    .border(
                                        if (on) 3.dp else 1.dp,
                                        if (on) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline,
                                        shape
                                    )
                                    .clickable { onPick(bg.id) },
                                contentAlignment = Alignment.Center
                            ) {
                                if (bg.brush == null) {
                                    Text(
                                        stringResource(R.string.bg_default), fontSize = 11.sp, textAlign = TextAlign.Center,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }
                }
                TextButton(onClick = onGallery) { Text(stringResource(R.string.bg_from_gallery)) }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text(stringResource(R.string.close)) } }
    )
}
