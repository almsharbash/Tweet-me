package com.tweetme.app.ui.chat

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Reply
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Done
import androidx.compose.material.icons.filled.DoneAll
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.outlined.ContentCopy
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.EmojiEmotions
import androidx.compose.material.icons.outlined.Image
import androidx.compose.material.icons.outlined.Mic
import androidx.compose.material.icons.outlined.Schedule
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.ContextCompat
import com.tweetme.app.R
import com.tweetme.app.core.Message
import com.tweetme.app.core.MsgType
import com.tweetme.app.core.REPLY_IMAGE
import com.tweetme.app.core.REPLY_VOICE
import com.tweetme.app.core.User
import com.tweetme.app.core.errorRes
import com.tweetme.app.data.AppPrefs
import com.tweetme.app.media.MediaUtils
import com.tweetme.app.media.VoicePlayer
import com.tweetme.app.media.VoiceRecorder
import com.tweetme.app.notify.Sounds
import com.tweetme.app.ui.common.Avatar
import com.tweetme.app.ui.common.dayLabel
import com.tweetme.app.ui.common.formatClock
import com.tweetme.app.ui.common.formatDuration
import com.tweetme.app.ui.common.presenceText
import com.tweetme.app.ui.common.sameDay
import com.tweetme.app.ui.theme.onColorFor
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

private val REACTIONS = listOf("👍", "❤️", "😂", "😮", "😢", "🙏")

private val EMOJIS: List<String> = (
    "😀 😃 😄 😁 😆 😅 😂 🤣 🙂 😉 😊 😇 🥰 😍 🤩 😘 😋 😜 🤪 😎 🤗 🤔 😐 😶 🙄 😏 😴 😌 😔 😷 🥵 🥶 😱 😢 😭 😤 😡 😈 💀 🤡 " +
        "👻 🙈 🙉 🙊 👍 👎 👌 🤞 👏 🙌 🙏 💪 👋 🤝 ❤️ 🧡 💛 💚 💙 💜 🖤 💔 ✨ 🔥 🎉 🎂 🌹 ☕ 🌙 ⭐ ☀️ ✅ ❌ 💯"
    ).split(" ")

private sealed interface ChatItem {
    val key: String

    data class Day(val label: String, val ms: Long) : ChatItem {
        override val key get() = "day_$ms"
    }

    data class Msg(val m: Message) : ChatItem {
        override val key get() = m.id
    }
}

private fun buildItems(ctx: Context, list: List<Message>): List<ChatItem> {
    val out = ArrayList<ChatItem>(list.size + 4)
    var prev: Message? = null
    for (m in list) {
        if (prev == null || !sameDay(prev.at, m.at)) out.add(ChatItem.Day(dayLabel(ctx, m.at), m.at))
        out.add(ChatItem.Msg(m))
        prev = m
    }
    return out
}

@Composable
fun ChatScreen(
    vm: ChatViewModel,
    me: User,
    player: VoicePlayer,
    prefs: AppPrefs,
    onBack: () -> Unit,
    onOpenSettings: () -> Unit
) {
    val ctx = LocalContext.current
    val clipboard = LocalClipboardManager.current
    val messages by vm.messages.collectAsState()
    val peer by vm.peer.collectAsState()
    val summary by vm.summary.collectAsState()
    val blocked by vm.blockedByMe.collectAsState()
    val replyTo by vm.replyTo.collectAsState()
    val ps by player.state.collectAsState()

    var text by rememberSaveable { mutableStateOf("") }
    var viewing by remember { mutableStateOf<String?>(null) }
    var recording by remember { mutableStateOf(false) }
    var recSec by remember { mutableIntStateOf(0) }
    var showEmoji by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf<String?>(null) }
    var actionMsg by remember { mutableStateOf<Message?>(null) }
    var editing by remember { mutableStateOf<Message?>(null) }
    val recorder = remember { VoiceRecorder(ctx) }
    val listState = rememberLazyListState()

    val now by produceState(System.currentTimeMillis()) {
        while (true) {
            delay(5_000)
            value = System.currentTimeMillis()
        }
    }
    val typing = summary?.let { it.peerTypingAt > 0 && now - it.peerTypingAt < 6_000 } ?: false
    val status: String? = if (typing) ctx.getString(R.string.typing) else presenceText(ctx, peer, now, me.showLastSeen)
    val peerRead = if (me.showReceipts) (summary?.peerReadAt ?: 0L) else 0L
    val peerName = peer?.name.orEmpty()

    LaunchedEffect(Unit) {
        vm.errors.collect { Toast.makeText(ctx, errorRes(it), Toast.LENGTH_SHORT).show() }
    }
    DisposableEffect(Unit) {
        onDispose {
            recorder.cancel()
            player.stop()
        }
    }
    BackHandler(enabled = query != null || showEmoji || editing != null) {
        when {
            showEmoji -> showEmoji = false
            editing != null -> { editing = null; text = "" }
            else -> query = null
        }
    }

    val q = query?.trim().orEmpty()
    val shown = remember(messages, q) {
        if (q.isEmpty()) messages
        else messages.filter { it.type == MsgType.TEXT && !it.deleted && it.text.contains(q, ignoreCase = true) }
    }
    val rows = remember(shown) { buildItems(ctx, shown) }
    LaunchedEffect(rows.size) {
        if (rows.isNotEmpty()) listState.scrollToItem(rows.lastIndex)
    }

    // صوت قصير عند وصول رسالة جديدة والمحادثة مفتوحة
    var lastCount by remember { mutableIntStateOf(-1) }
    LaunchedEffect(messages.size) {
        val last = messages.lastOrNull()
        if (lastCount >= 0 && messages.size > lastCount && last != null && last.from != me.uid &&
            prefs.sounds && System.currentTimeMillis() - last.at < 4_000
        ) {
            Sounds.ping(ctx)
        }
        lastCount = messages.size
    }

    fun beginRecording() {
        if (recorder.start()) {
            recording = true
            recSec = 0
        } else {
            Toast.makeText(ctx, R.string.err_record, Toast.LENGTH_SHORT).show()
        }
    }

    fun finishRecording(send: Boolean) {
        recording = false
        val r = recorder.stop()
        if (send && r != null) vm.sendVoice(r)
    }

    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) beginRecording() else Toast.makeText(ctx, R.string.mic_permission, Toast.LENGTH_SHORT).show()
    }
    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) vm.sendImage(uri)
    }

    LaunchedEffect(recording) {
        while (recording) {
            delay(250)
            recSec = recorder.elapsedSec()
            if (recSec >= VoiceRecorder.MAX_SEC) finishRecording(true)
        }
    }

    fun submit() {
        val e = editing
        if (e != null) {
            vm.edit(e, text)
            editing = null
        } else {
            vm.sendText(text)
        }
        text = ""
    }

    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).imePadding()) {
        ChatTopBar(
            peer = peer,
            status = status,
            query = query,
            onQuery = { query = it },
            muted = summary?.muted == true,
            canMute = summary != null,
            blocked = blocked,
            onBack = onBack,
            onMute = { vm.toggleMute() },
            onBlock = { vm.setBlocked(!blocked) },
            onWallpaper = onOpenSettings
        )

        ChatBackground(prefs, Modifier.weight(1f).fillMaxWidth()) {
            LazyColumn(
                state = listState,
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                items(rows, key = { it.key }) { item ->
                    when (item) {
                        is ChatItem.Day -> DayChip(item.label)
                        is ChatItem.Msg -> {
                            val m = item.m
                            Bubble(
                                m = m,
                                mine = m.from == me.uid,
                                read = !m.pending && m.at <= peerRead,
                                prefs = prefs,
                                meUid = me.uid,
                                peerName = peerName,
                                playing = ps.id == m.id && ps.playing,
                                progress = if (ps.id == m.id) ps.progress else 0f,
                                onPlay = { player.toggle(m.id, m.url) },
                                onImage = { viewing = m.url },
                                onLong = { actionMsg = m }
                            )
                        }
                    }
                }
            }
        }

        if (blocked) {
            Surface(color = MaterialTheme.colorScheme.surface) {
                Row(
                    Modifier.fillMaxWidth().navigationBarsPadding().padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(stringResource(R.string.you_blocked), Modifier.weight(1f), color = MaterialTheme.colorScheme.onSurfaceVariant)
                    TextButton(onClick = { vm.setBlocked(false) }) { Text(stringResource(R.string.unblock)) }
                }
            }
        } else {
            val reply = replyTo
            if (reply != null) {
                val who = if (reply.from == me.uid) stringResource(R.string.you) else peerName
                val body = when (reply.type) {
                    MsgType.TEXT -> reply.text
                    MsgType.IMAGE -> stringResource(R.string.msg_image)
                    MsgType.VOICE -> stringResource(R.string.msg_voice)
                }
                QuoteBar(who, body) { vm.setReply(null) }
            }
            if (editing != null) {
                QuoteBar(stringResource(R.string.editing), editing?.text.orEmpty()) {
                    editing = null
                    text = ""
                }
            }
            Composer(
                text = text,
                onText = {
                    text = it
                    if (it.isNotBlank()) vm.typing()
                },
                recording = recording,
                recSec = recSec,
                enterSends = prefs.enterSends,
                editing = editing != null,
                onPickImage = { imagePicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
                onToggleEmoji = { showEmoji = !showEmoji },
                onSend = { submit() },
                onMic = {
                    if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                        beginRecording()
                    } else {
                        permLauncher.launch(Manifest.permission.RECORD_AUDIO)
                    }
                },
                onRecCancel = { finishRecording(false) },
                onRecSend = { finishRecording(true) }
            )
            if (showEmoji) EmojiPanel { text += it }
        }
    }

    actionMsg?.let { m ->
        MessageActions(
            m = m,
            mine = m.from == me.uid,
            onDismiss = { actionMsg = null },
            onReact = { vm.react(m, it); actionMsg = null },
            onReply = { vm.setReply(m); actionMsg = null },
            onCopy = { clipboard.setText(AnnotatedString(m.text)); actionMsg = null },
            onEdit = { editing = m; text = m.text; vm.setReply(null); actionMsg = null },
            onDeleteMe = { vm.deleteForMe(m); actionMsg = null },
            onDeleteAll = { vm.deleteForEveryone(m); actionMsg = null }
        )
    }

    viewing?.let { url -> ImageViewer(url) { viewing = null } }
}

@Composable
private fun ChatTopBar(
    peer: User?,
    status: String?,
    query: String?,
    onQuery: (String?) -> Unit,
    muted: Boolean,
    canMute: Boolean,
    blocked: Boolean,
    onBack: () -> Unit,
    onMute: () -> Unit,
    onBlock: () -> Unit,
    onWallpaper: () -> Unit
) {
    var menu by remember { mutableStateOf(false) }
    Surface(color = MaterialTheme.colorScheme.surface) {
        if (query != null) {
            Row(
                Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 4.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { onQuery(null) }) {
                    Icon(Icons.Filled.Close, contentDescription = stringResource(R.string.close))
                }
                OutlinedTextField(
                    value = query, onValueChange = { onQuery(it) },
                    placeholder = { Text(stringResource(R.string.search_in_chat)) },
                    singleLine = true, modifier = Modifier.weight(1f).padding(end = 8.dp),
                    shape = RoundedCornerShape(24.dp)
                )
            }
        } else {
            Row(
                Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 4.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = stringResource(R.string.back))
                }
                Avatar(peer, 38.dp)
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text(peer?.name ?: "…", fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    if (status != null) {
                        Text(
                            status, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp,
                            maxLines = 1, overflow = TextOverflow.Ellipsis
                        )
                    }
                }
                IconButton(onClick = { onQuery("") }) {
                    Icon(Icons.Filled.Search, contentDescription = stringResource(R.string.search_in_chat))
                }
                Box {
                    IconButton(onClick = { menu = true }) {
                        Icon(Icons.Filled.MoreVert, contentDescription = stringResource(R.string.more))
                    }
                    DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                        if (canMute) {
                            DropdownMenuItem(
                                text = { Text(stringResource(if (muted) R.string.unmute else R.string.mute)) },
                                onClick = { menu = false; onMute() }
                            )
                        }
                        DropdownMenuItem(
                            text = { Text(stringResource(if (blocked) R.string.unblock else R.string.block)) },
                            onClick = { menu = false; onBlock() }
                        )
                        DropdownMenuItem(
                            text = { Text(stringResource(R.string.wallpaper)) },
                            onClick = { menu = false; onWallpaper() }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun DayChip(label: String) {
    Box(Modifier.fillMaxWidth().padding(vertical = 6.dp), contentAlignment = Alignment.Center) {
        Surface(shape = RoundedCornerShape(12.dp), color = MaterialTheme.colorScheme.surface.copy(alpha = 0.92f)) {
            Text(
                label,
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 3.dp),
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontSize = 12.sp
            )
        }
    }
}

@Composable
private fun Bubble(
    m: Message,
    mine: Boolean,
    read: Boolean,
    prefs: AppPrefs,
    meUid: String,
    peerName: String,
    playing: Boolean,
    progress: Float,
    onPlay: () -> Unit,
    onImage: () -> Unit,
    onLong: () -> Unit
) {
    val ctx = LocalContext.current
    val scheme = MaterialTheme.colorScheme
    val bg = if (mine) Color(if (prefs.bubble != 0L) prefs.bubble else prefs.accent) else scheme.surfaceVariant
    val fg = if (mine) onColorFor(bg) else scheme.onSurface
    val shape = RoundedCornerShape(
        topStart = if (mine) 14.dp else 4.dp, topEnd = if (mine) 4.dp else 14.dp,
        bottomStart = 14.dp, bottomEnd = 14.dp
    )

    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (mine) Arrangement.End else Arrangement.Start) {
        Surface(
            color = bg, contentColor = fg, shape = shape,
            modifier = Modifier.widthIn(max = 300.dp).pointerInput(m.id, m.deleted) {
                detectTapGestures(
                    onLongPress = { onLong() },
                    onTap = { if (m.type == MsgType.IMAGE && !m.deleted) onImage() }
                )
            }
        ) {
            Column(Modifier.padding(horizontal = 10.dp, vertical = 6.dp)) {
                if (m.deleted) {
                    Text(
                        stringResource(R.string.msg_deleted), fontSize = 14.sp,
                        fontStyle = FontStyle.Italic, color = fg.copy(alpha = 0.7f)
                    )
                } else {
                    if (m.replyToId.isNotEmpty()) ReplyQuote(m, meUid, peerName, fg)
                    when (m.type) {
                        MsgType.TEXT -> Text(m.text, fontSize = 15.sp)
                        MsgType.IMAGE -> ChatImage(m.url)
                        MsgType.VOICE -> VoiceBubble(m.durSec, playing, progress, fg, onPlay)
                    }
                }
                Row(
                    Modifier.align(Alignment.End).padding(top = 2.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    if (m.edited && !m.deleted) Text(stringResource(R.string.edited), fontSize = 11.sp, color = fg.copy(alpha = 0.75f))
                    Text(formatClock(ctx, m.at), fontSize = 11.sp, color = fg.copy(alpha = 0.75f))
                    if (mine) {
                        val icon = when {
                            m.pending -> Icons.Outlined.Schedule
                            read -> Icons.Filled.DoneAll
                            else -> Icons.Filled.Done
                        }
                        Icon(
                            icon, contentDescription = null, modifier = Modifier.size(14.dp),
                            tint = if (read) Color(0xFF6FE3FF) else fg.copy(alpha = 0.75f)
                        )
                    }
                }
                if (m.reactions.isNotEmpty() && !m.deleted) {
                    val grouped = m.reactions.values.groupingBy { it }.eachCount()
                    Surface(
                        shape = RoundedCornerShape(10.dp), color = fg.copy(alpha = 0.15f),
                        modifier = Modifier.align(Alignment.Start).padding(top = 3.dp)
                    ) {
                        Text(
                            grouped.entries.joinToString(" ") { if (it.value > 1) "${it.key}${it.value}" else it.key },
                            fontSize = 13.sp, modifier = Modifier.padding(horizontal = 6.dp, vertical = 1.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun ReplyQuote(m: Message, meUid: String, peerName: String, fg: Color) {
    val who = if (m.replyFrom == meUid) stringResource(R.string.you) else peerName
    val body = when (m.replyText) {
        REPLY_IMAGE -> stringResource(R.string.msg_image)
        REPLY_VOICE -> stringResource(R.string.msg_voice)
        else -> m.replyText
    }
    Row(
        Modifier.padding(bottom = 4.dp).height(IntrinsicSize.Min)
            .clip(RoundedCornerShape(8.dp)).background(fg.copy(alpha = 0.12f))
    ) {
        Box(Modifier.width(4.dp).fillMaxHeight().background(MaterialTheme.colorScheme.primary))
        Column(Modifier.padding(horizontal = 8.dp, vertical = 4.dp)) {
            Text(who, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = fg.copy(alpha = 0.9f))
            Text(body, fontSize = 12.sp, maxLines = 2, overflow = TextOverflow.Ellipsis, color = fg.copy(alpha = 0.8f))
        }
    }
}

@Composable
private fun ChatImage(url: String) {
    val bmp by produceState<ImageBitmap?>(null, url) {
        value = withContext(Dispatchers.Default) { MediaUtils.bitmapFromDataUri(url)?.asImageBitmap() }
    }
    val b = bmp
    if (b == null) {
        Box(Modifier.size(width = 200.dp, height = 140.dp))
    } else {
        Image(
            bitmap = b, contentDescription = stringResource(R.string.msg_image),
            contentScale = ContentScale.Fit,
            modifier = Modifier.heightIn(max = 280.dp).clip(RoundedCornerShape(10.dp))
        )
    }
}

@Composable
private fun VoiceBubble(durSec: Int, playing: Boolean, progress: Float, fg: Color, onPlay: () -> Unit) {
    Row(Modifier.widthIn(min = 190.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        IconButton(
            onClick = onPlay,
            modifier = Modifier.size(36.dp),
            colors = IconButtonDefaults.iconButtonColors(containerColor = fg.copy(alpha = 0.2f), contentColor = fg)
        ) {
            Icon(if (playing) Icons.Filled.Pause else Icons.Filled.PlayArrow, contentDescription = stringResource(R.string.play))
        }
        LinearProgressIndicator(
            progress = { progress },
            modifier = Modifier.weight(1f),
            color = fg,
            trackColor = fg.copy(alpha = 0.25f)
        )
        Text(formatDuration(durSec), fontSize = 12.sp, color = fg.copy(alpha = 0.85f))
    }
}

@Composable
private fun QuoteBar(title: String, body: String, onClose: () -> Unit) {
    Surface(color = MaterialTheme.colorScheme.surfaceVariant) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.width(4.dp).height(34.dp).background(MaterialTheme.colorScheme.primary))
            Column(Modifier.weight(1f).padding(horizontal = 8.dp)) {
                Text(title, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                Text(body, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            IconButton(onClick = onClose) { Icon(Icons.Filled.Close, contentDescription = stringResource(R.string.cancel)) }
        }
    }
}

@Composable
private fun Composer(
    text: String,
    onText: (String) -> Unit,
    recording: Boolean,
    recSec: Int,
    enterSends: Boolean,
    editing: Boolean,
    onPickImage: () -> Unit,
    onToggleEmoji: () -> Unit,
    onSend: () -> Unit,
    onMic: () -> Unit,
    onRecCancel: () -> Unit,
    onRecSend: () -> Unit
) {
    val primary = MaterialTheme.colorScheme.primary
    val sendColors = IconButtonDefaults.iconButtonColors(containerColor = primary, contentColor = MaterialTheme.colorScheme.onPrimary)
    Surface(color = Color.Transparent) {
        Row(
            Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 6.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            if (recording) {
                IconButton(onClick = onRecCancel) { Icon(Icons.Filled.Close, contentDescription = stringResource(R.string.cancel)) }
                Row(Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Box(Modifier.size(10.dp).background(MaterialTheme.colorScheme.error, CircleShape))
                    Text(formatDuration(recSec), color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.SemiBold)
                }
                IconButton(onClick = onRecSend, colors = sendColors) {
                    Icon(Icons.AutoMirrored.Filled.Send, contentDescription = stringResource(R.string.send))
                }
            } else {
                Surface(
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(26.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = onToggleEmoji) {
                            Icon(
                                Icons.Outlined.EmojiEmotions, contentDescription = stringResource(R.string.emoji),
                                tint = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        TextField(
                            value = text,
                            onValueChange = { if (it.length <= 4000) onText(it) },
                            modifier = Modifier.weight(1f),
                            placeholder = { Text(stringResource(R.string.type_message)) },
                            maxLines = 5,
                            colors = TextFieldDefaults.colors(
                                focusedContainerColor = Color.Transparent,
                                unfocusedContainerColor = Color.Transparent,
                                disabledContainerColor = Color.Transparent,
                                focusedIndicatorColor = Color.Transparent,
                                unfocusedIndicatorColor = Color.Transparent,
                                disabledIndicatorColor = Color.Transparent
                            ),
                            keyboardOptions = if (enterSends) KeyboardOptions(imeAction = ImeAction.Send) else KeyboardOptions.Default,
                            keyboardActions = KeyboardActions(onSend = { if (text.isNotBlank()) onSend() })
                        )
                        if (text.isBlank() && !editing) {
                            IconButton(onClick = onPickImage) {
                                Icon(
                                    Icons.Outlined.Image, contentDescription = stringResource(R.string.attach_image),
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
                if (text.isBlank() && !editing) {
                    IconButton(onClick = onMic, colors = sendColors, modifier = Modifier.size(48.dp)) {
                        Icon(Icons.Outlined.Mic, contentDescription = stringResource(R.string.record_voice))
                    }
                } else {
                    IconButton(onClick = onSend, colors = sendColors, modifier = Modifier.size(48.dp)) {
                        if (editing) {
                            Icon(Icons.Filled.Check, contentDescription = stringResource(R.string.save))
                        } else {
                            Icon(Icons.AutoMirrored.Filled.Send, contentDescription = stringResource(R.string.send))
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun EmojiPanel(onPick: (String) -> Unit) {
    LazyVerticalGrid(
        columns = GridCells.Fixed(8),
        modifier = Modifier.fillMaxWidth().height(220.dp).background(MaterialTheme.colorScheme.surface)
    ) {
        items(EMOJIS) { e ->
            Box(Modifier.clickable { onPick(e) }.padding(6.dp), contentAlignment = Alignment.Center) {
                Text(e, fontSize = 24.sp)
            }
        }
    }
}

@Composable
private fun ActionRow(icon: ImageVector, label: Int, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 20.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(stringResource(label))
    }
}

@Composable
private fun MessageActions(
    m: Message,
    mine: Boolean,
    onDismiss: () -> Unit,
    onReact: (String) -> Unit,
    onReply: () -> Unit,
    onCopy: () -> Unit,
    onEdit: () -> Unit,
    onDeleteMe: () -> Unit,
    onDeleteAll: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Surface(shape = RoundedCornerShape(20.dp), color = MaterialTheme.colorScheme.surface) {
            Column(Modifier.padding(vertical = 8.dp)) {
                if (!m.deleted) {
                    Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                        REACTIONS.forEach { e ->
                            Text(e, fontSize = 26.sp, modifier = Modifier.clip(CircleShape).clickable { onReact(e) }.padding(6.dp))
                        }
                    }
                    HorizontalDivider(color = MaterialTheme.colorScheme.outline)
                    ActionRow(Icons.AutoMirrored.Filled.Reply, R.string.reply, onReply)
                    if (m.type == MsgType.TEXT) ActionRow(Icons.Outlined.ContentCopy, R.string.copy, onCopy)
                    if (mine && m.type == MsgType.TEXT) ActionRow(Icons.Outlined.Edit, R.string.edit, onEdit)
                }
                ActionRow(Icons.Outlined.Delete, R.string.delete_for_me, onDeleteMe)
                if (mine && !m.deleted) ActionRow(Icons.Outlined.Delete, R.string.delete_for_all, onDeleteAll)
            }
        }
    }
}

@Composable
private fun ImageViewer(url: String, onDismiss: () -> Unit) {
    val bmp by produceState<ImageBitmap?>(null, url) {
        value = withContext(Dispatchers.Default) { MediaUtils.bitmapFromDataUri(url)?.asImageBitmap() }
    }
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Box(Modifier.fillMaxSize().background(Color.Black).clickable(onClick = onDismiss), contentAlignment = Alignment.Center) {
            val b = bmp
            if (b != null) Image(bitmap = b, contentDescription = null, contentScale = ContentScale.Fit, modifier = Modifier.fillMaxSize())
        }
    }
}
