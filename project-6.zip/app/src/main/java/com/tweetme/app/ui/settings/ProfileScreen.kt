package com.tweetme.app.ui.settings

import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.CameraAlt
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.unit.dp
import com.tweetme.app.R
import com.tweetme.app.core.User
import com.tweetme.app.core.errorKind
import com.tweetme.app.core.errorRes
import com.tweetme.app.data.ChatBackend
import com.tweetme.app.media.MediaUtils
import com.tweetme.app.ui.common.Avatar
import com.tweetme.app.ui.common.SubTopBar
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private const val ABOUT_MAX = 100

/** تعديل الملف الشخصي: الصورة والاسم والحالة النصية. */
@Composable
fun ProfileScreen(me: User, backend: ChatBackend, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var name by remember(me.uid) { mutableStateOf(me.name) }
    var about by remember(me.uid) { mutableStateOf(me.about) }
    var busy by remember { mutableStateOf(false) }

    fun toast(res: Int) = Toast.makeText(ctx, res, Toast.LENGTH_SHORT).show()

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) {
            scope.launch {
                busy = true
                val bytes = withContext(Dispatchers.IO) {
                    runCatching { MediaUtils.compressImage(ctx, uri, 320, 45_000) }.getOrNull()
                }
                if (bytes == null) {
                    toast(R.string.err_too_big)
                } else {
                    try {
                        backend.setPhoto(me.uid, MediaUtils.toDataUri("image/jpeg", bytes))
                        toast(R.string.saved)
                    } catch (e: Exception) {
                        toast(errorRes(e.errorKind()))
                    }
                }
                busy = false
            }
        }
    }

    Column(Modifier.fillMaxSize().imePadding()) {
        SubTopBar(stringResource(R.string.profile), onBack)
        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(contentAlignment = Alignment.BottomEnd) {
                Avatar(me, 120.dp)
                Box(
                    Modifier.size(40.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primary)
                        .clickable(enabled = !busy) {
                            picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                        },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        Icons.Outlined.CameraAlt, contentDescription = stringResource(R.string.change_photo),
                        tint = MaterialTheme.colorScheme.onPrimary
                    )
                }
            }
            if (me.photo.isNotEmpty()) {
                TextButton(
                    onClick = {
                        scope.launch {
                            try {
                                backend.setPhoto(me.uid, "")
                            } catch (e: Exception) {
                                toast(errorRes(e.errorKind()))
                            }
                        }
                    },
                    enabled = !busy
                ) { Text(stringResource(R.string.remove_photo)) }
            }
            OutlinedTextField(
                value = name, onValueChange = { if (it.length <= 40) name = it },
                label = { Text(stringResource(R.string.f_name)) }, singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = about, onValueChange = { if (it.length <= ABOUT_MAX) about = it },
                label = { Text(stringResource(R.string.about_label)) },
                supportingText = { Text("${about.length}/$ABOUT_MAX") },
                maxLines = 3,
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = "@" + me.username, onValueChange = {},
                label = { Text(stringResource(R.string.f_username)) },
                readOnly = true, singleLine = true,
                textStyle = MaterialTheme.typography.bodyLarge.copy(textDirection = TextDirection.Ltr),
                supportingText = { Text(stringResource(R.string.username_fixed)) },
                modifier = Modifier.fillMaxWidth()
            )
            Button(
                onClick = {
                    if (name.trim().length < 2) {
                        toast(R.string.err_name)
                    } else {
                        scope.launch {
                            busy = true
                            try {
                                backend.updateProfile(me.uid, name.trim(), about.trim())
                                toast(R.string.saved)
                            } catch (e: Exception) {
                                toast(errorRes(e.errorKind()))
                            }
                            busy = false
                        }
                    }
                },
                enabled = !busy,
                modifier = Modifier.fillMaxWidth()
            ) { Text(stringResource(R.string.save_changes)) }
        }
    }
}
