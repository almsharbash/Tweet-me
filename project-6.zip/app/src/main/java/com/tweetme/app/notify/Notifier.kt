package com.tweetme.app.notify

import android.Manifest
import android.annotation.SuppressLint
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.RingtoneManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.tweetme.app.MainActivity
import com.tweetme.app.R

/**
 * إشعارات النظام عند وصول رسالة والتطبيق في الخلفية.
 * ملاحظة: تعمل ما دام أندرويد يُبقي التطبيق حياً. الإشعار الدائم والتطبيق مغلق يحتاج FCM (مرحلة لاحقة).
 */
class Notifier(private val ctx: Context) {
    private val channelId = "messages"

    init {
        if (Build.VERSION.SDK_INT >= 26) {
            val ch = NotificationChannel(channelId, ctx.getString(R.string.notif_channel), NotificationManager.IMPORTANCE_HIGH)
            ctx.getSystemService(NotificationManager::class.java)?.createNotificationChannel(ch)
        }
    }

    fun canNotify(): Boolean =
        Build.VERSION.SDK_INT < 33 ||
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED

    @SuppressLint("MissingPermission")
    fun message(chatId: String, title: String, body: String) {
        if (!canNotify()) return
        val intent = Intent(ctx, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pi = PendingIntent.getActivity(ctx, 0, intent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val n = NotificationCompat.Builder(ctx, channelId)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setAutoCancel(true)
            .setContentIntent(pi)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .build()
        NotificationManagerCompat.from(ctx).notify(chatId.hashCode(), n)
    }
}

/** صوت قصير عند وصول رسالة والمحادثة مفتوحة. */
object Sounds {
    fun ping(ctx: Context) {
        runCatching {
            RingtoneManager.getRingtone(ctx, RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION))?.play()
        }
    }
}
