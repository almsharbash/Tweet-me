package com.tweetme.app.ui.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.TextButton
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tweetme.app.data.AppPrefs
import com.tweetme.app.ui.theme.onColorFor

/** مكوّنات مشتركة بين شاشات الإعدادات. */

@Composable
internal fun SectionTitle(res: Int) {
    Text(
        stringResource(res),
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        fontSize = 13.sp,
        fontWeight = FontWeight.Bold,
        modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 6.dp)
    )
}

@Composable
internal fun SectionCard(content: @Composable () -> Unit) {
    Surface(color = MaterialTheme.colorScheme.surface, modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) { content() }
    }
}

/** صف إعداد: أيقونة وعنوان وسطر توضيحي، يُضغط للانتقال. */
@Composable
internal fun SettingRow(icon: ImageVector, title: Int, subtitle: Int, onClick: (() -> Unit)? = null) {
    val base = Modifier.fillMaxWidth()
    Row(
        (if (onClick != null) base.clickable(onClick = onClick) else base).padding(horizontal = 18.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
        Column(Modifier.weight(1f)) {
            Text(stringResource(title), fontSize = 16.sp)
            Text(stringResource(subtitle), color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
        }
    }
}

/** صف بمفتاح تشغيل وإيقاف. */
@Composable
internal fun SwitchRow(title: Int, subtitle: Int, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable { onChange(!checked) }.padding(horizontal = 18.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Column(Modifier.weight(1f)) {
            Text(stringResource(title), fontSize = 16.sp)
            Text(stringResource(subtitle), color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
        }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
internal fun Pill(label: String, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    Surface(
        modifier = modifier.clickable(onClick = onClick),
        shape = RoundedCornerShape(10.dp),
        color = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant
    ) {
        Text(
            label,
            modifier = Modifier.padding(vertical = 10.dp),
            textAlign = TextAlign.Center,
            fontSize = 14.sp,
            color = if (selected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
internal fun Swatch(color: Long, selected: Boolean, onClick: () -> Unit) {
    val c = Color(color)
    Box(
        Modifier.size(38.dp).clip(CircleShape).background(c)
            .then(if (selected) Modifier.border(3.dp, MaterialTheme.colorScheme.onSurface, CircleShape) else Modifier)
            .clickable(onClick = onClick)
    )
}

@Composable
internal fun PreviewBubble(text: String, mine: Boolean, prefs: AppPrefs) {
    val bg = if (mine) Color(if (prefs.bubble != 0L) prefs.bubble else prefs.accent) else MaterialTheme.colorScheme.surfaceVariant
    val fg = if (mine) onColorFor(bg) else MaterialTheme.colorScheme.onSurface
    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (mine) Arrangement.End else Arrangement.Start) {
        Surface(color = bg, contentColor = fg, shape = RoundedCornerShape(12.dp)) {
            Text(text, modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp), fontSize = 13.sp)
        }
    }
}

/** صف يعرض اسم الإعداد ودائرة صغيرة بلونه الحالي؛ الضغط يفتح نافذة الاختيار. */
@Composable
internal fun ColorRow(title: Int, color: Long, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 18.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(stringResource(title), fontSize = 16.sp, modifier = Modifier.weight(1f))
        Box(
            Modifier.size(28.dp).clip(CircleShape).background(Color(color))
                .border(1.dp, MaterialTheme.colorScheme.outline, CircleShape)
        )
    }
}

private val HEX_REGEX = Regex("^#?[0-9a-fA-F]{6}$")

/**
 * نافذة اختيار لون: شبكة ألوان جاهزة وحقل لون مخصص.
 * [defaultColor] يُعرض كخيار أول بقيمة 0 (يعني «نفس لون التطبيق») عندما يكون غير null.
 */
@Composable
internal fun ColorPickerDialog(
    title: Int,
    colors: List<Long>,
    selected: Long,
    defaultColor: Long? = null,
    onPick: (Long) -> Unit,
    onDismiss: () -> Unit
) {
    var hex by remember { mutableStateOf("") }
    val all: List<Pair<Long, Long>> =
        (if (defaultColor != null) listOf(0L to defaultColor) else emptyList()) + colors.map { it to it }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(title)) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                all.chunked(5).forEach { row ->
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        row.forEach { (value, shown) ->
                            Swatch(shown, selected == value) { onPick(value); onDismiss() }
                        }
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = hex, onValueChange = { hex = it.take(7) },
                        label = { Text(stringResource(com.tweetme.app.R.string.custom_color)) },
                        placeholder = { Text("#2F7BFF") },
                        singleLine = true,
                        textStyle = MaterialTheme.typography.bodyLarge.copy(textDirection = TextDirection.Ltr),
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedButton(
                        enabled = HEX_REGEX.matches(hex),
                        onClick = { onPick(hex.removePrefix("#").toLong(16) or 0xFF000000L); onDismiss() }
                    ) { Text(stringResource(com.tweetme.app.R.string.apply)) }
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text(stringResource(com.tweetme.app.R.string.close)) } }
    )
}
