package com.tweetme.app.ui.chat

import android.content.Context
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.tweetme.app.core.ChatFlag
import com.tweetme.app.core.ChatSummary
import com.tweetme.app.core.Draft
import com.tweetme.app.core.ErrorKind
import com.tweetme.app.core.Message
import com.tweetme.app.core.MsgType
import com.tweetme.app.core.REPLY_IMAGE
import com.tweetme.app.core.REPLY_VOICE
import com.tweetme.app.core.User
import com.tweetme.app.core.errorKind
import com.tweetme.app.data.ChatBackend
import com.tweetme.app.media.MediaUtils
import com.tweetme.app.media.Recorded
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

/** منطق شاشة المحادثة: الرسائل والإرسال والرد والتفاعل والحذف والحظر، بلا أي كود واجهة. */
class ChatViewModel(
    private val app: Context,
    private val backend: ChatBackend,
    private val me: String,
    private val peerUid: String
) : ViewModel() {

    private val chatId = listOf(me, peerUid).sorted().joinToString("_")

    /** الرسائل بعد إخفاء ما حذفته عندي فقط. */
    val messages: StateFlow<List<Message>> = backend.messages(chatId)
        .map { list -> list.filter { me !in it.hiddenFor } }
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val summary: StateFlow<ChatSummary?> = backend.chats(me)
        .map { list -> list.firstOrNull { it.id == chatId } }
        .stateIn(viewModelScope, SharingStarted.Eagerly, null)

    val peer: StateFlow<User?> = backend.watchUser(peerUid)
        .stateIn(viewModelScope, SharingStarted.Eagerly, null)

    val blockedByMe: StateFlow<Boolean> = backend.blocked(me)
        .map { peerUid in it }
        .stateIn(viewModelScope, SharingStarted.Eagerly, false)

    private val _replyTo = MutableStateFlow<Message?>(null)
    val replyTo: StateFlow<Message?> = _replyTo

    private val _errors = MutableSharedFlow<ErrorKind>(extraBufferCapacity = 4)
    val errors: SharedFlow<ErrorKind> = _errors.asSharedFlow()

    private var lastTypingAt = 0L

    init {
        viewModelScope.launch {
            var marked = 0L
            messages.collect { list ->
                val last = list.lastOrNull()
                if (last != null && last.from != me && last.at > marked) {
                    marked = last.at
                    backend.markRead(chatId, me)
                }
            }
        }
    }

    // ---------- الإرسال ----------

    fun sendText(text: String) {
        val t = text.trim()
        if (t.isNotEmpty()) post(draft(MsgType.TEXT, text = t))
    }

    fun sendImage(uri: Uri) {
        viewModelScope.launch(Dispatchers.Default) {
            val bytes = runCatching { MediaUtils.compressImage(app, uri, 900, 480_000) }.getOrNull()
            if (bytes == null) {
                _errors.tryEmit(ErrorKind.TOO_BIG)
            } else {
                post(draft(MsgType.IMAGE, url = MediaUtils.toDataUri("image/jpeg", bytes)))
            }
        }
    }

    fun sendVoice(r: Recorded) {
        if (r.bytes.size > 600_000) {
            _errors.tryEmit(ErrorKind.TOO_BIG)
            return
        }
        post(draft(MsgType.VOICE, url = MediaUtils.toDataUri("audio/mp4", r.bytes), dur = r.durSec))
    }

    /** يبني المسودة ويرفق الرد الحالي إن وُجد ثم يلغيه. */
    private fun draft(type: MsgType, text: String = "", url: String = "", dur: Int = 0): Draft {
        val r = _replyTo.value
        _replyTo.value = null
        if (r == null) return Draft(type, text, url, dur)
        val snippet = when (r.type) {
            MsgType.TEXT -> r.text.take(120)
            MsgType.IMAGE -> REPLY_IMAGE
            MsgType.VOICE -> REPLY_VOICE
        }
        return Draft(type, text, url, dur, replyToId = r.id, replyText = snippet, replyFrom = r.from)
    }

    private fun post(d: Draft) {
        launchSafe { backend.send(chatId, me, peerUid, d) }
    }

    private fun launchSafe(block: suspend () -> Unit) {
        viewModelScope.launch {
            try {
                block()
            } catch (e: Exception) {
                _errors.tryEmit(e.errorKind())
            }
        }
    }

    // ---------- الرد والتفاعل والحذف والتعديل ----------

    fun setReply(m: Message?) {
        _replyTo.value = m
    }

    fun react(m: Message, emoji: String) {
        val mine = m.reactions[me]
        launchSafe { backend.react(chatId, m.id, me, if (mine == emoji) null else emoji) }
    }

    fun deleteForMe(m: Message) {
        launchSafe { backend.deleteForMe(chatId, m.id, me) }
    }

    fun deleteForEveryone(m: Message) {
        launchSafe { backend.deleteForEveryone(chatId, m.id) }
    }

    fun edit(m: Message, newText: String) {
        val t = newText.trim()
        if (t.isNotEmpty() && t != m.text) launchSafe { backend.editMessage(chatId, m.id, t) }
    }

    // ---------- الحضور والحظر والكتم ----------

    /** يُستدعى أثناء الكتابة؛ يرسل «يكتب الآن» مرة كل 3 ثوانٍ كحد أقصى. */
    fun typing() {
        val now = System.currentTimeMillis()
        if (now - lastTypingAt < 3_000) return
        lastTypingAt = now
        viewModelScope.launch { backend.setTyping(chatId, me) }
    }

    fun setBlocked(block: Boolean) {
        launchSafe { if (block) backend.block(me, peerUid) else backend.unblock(me, peerUid) }
    }

    fun toggleMute() {
        val muted = summary.value?.muted ?: return
        launchSafe { backend.setChatFlag(chatId, me, ChatFlag.MUTED, !muted) }
    }
}
