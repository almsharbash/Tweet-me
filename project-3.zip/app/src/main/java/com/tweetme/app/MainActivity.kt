package com.tweetme.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.tweetme.app.data.AppPrefs
import com.tweetme.app.ui.AppNav
import com.tweetme.app.ui.theme.TweetMeTheme
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    private lateinit var container: AppContainer

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        container = (application as TweetMeApp).container

        // نبضة حضور كل 45 ثانية أثناء ظهور التطبيق (لـ «متصل الآن» و«آخر ظهور»)
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.RESUMED) {
                while (true) {
                    container.backend.currentUser.value?.let { container.backend.heartbeat(it.uid) }
                    delay(45_000)
                }
            }
        }

        setContent {
            val prefs by container.prefs.prefs.collectAsState(initial = AppPrefs())
            TweetMeTheme(prefs) {
                AppNav(container, prefs)
            }
        }
    }

    override fun onStart() {
        super.onStart()
        container.inForeground = true
    }

    override fun onStop() {
        super.onStop()
        container.inForeground = false
    }
}
