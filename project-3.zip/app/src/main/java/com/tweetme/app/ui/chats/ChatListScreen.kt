package com.tweetme.app.ui.chats

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.outlined.Archive
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.tweetme.app.R
import com.tweetme.app.core.ChatFlag
import com.tweetme.app.core.ChatSummary
import com.tweetme.app.core.MsgType
import com.tweetme.app.core.User
import com.tweetme.app.core.errorKind
import com.tweetme.app.core.errorRes
import com.tweetme.app.data.ChatBackend
import com.tweetme.app.ui.common.Avatar
import com.tweetme.app.ui.common.ScreenTopBar
import com.tweetme.app.ui.common.SubTopBar
import com.tweetme.app.ui.common.listTime
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class ChatRow(val summary: ChatSummary, val peer: User?)

/** منطق قائمة المحادثات: يتابع كل طرف مباشرة ليظهر اسمه وصورته المحدَّثان. */
class ChatListViewModel(private val backend: ChatBackend, private val me: String) : ViewModel() {
    private val peers = MutableStateFlow<Map<String, User>>(emptyMap())
    private val watched = HashSet<String>()

    private val chats: StateFlow<List<ChatSummary>> =
        backend.chats(me).stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val rows: StateFlow<List<ChatRow>> = combine(chats, peers) { list, p ->
        list.map { ChatRow(it, p[it.peerUid]) }
    }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    init {
        viewModelScope.launch {
            chats.collect { list ->
                for (uid in list.map { it.peerUid }.distinct()) {
                    if (watched.add(uid)) {
                        launch {
                            backend.watchUser(uid).collect { u ->
                                if (u != null) peers.update { m -> m + (uid to u) }
                            }
                        }
                    }
                }
            }
        }
    }

    fun setFlag(chatId: String, flag: ChatFlag, value: Boolean) {
        viewModelScope.launch { runCatching { backend.setChatFlag(chatId, me, flag, value) } }
    }
}

@Composable
fun ChatListScreen(vm: ChatListViewModel, backend: ChatBackend, me: User, onOpenChat: (String) -> Unit) {
    val rows by vm.rows.collectAsState()
    var showNew by remember { mutableStateOf(false) }
    var search by remember { mutableStateOf<String?>(null) }
    var showArchived by remember { mutableStateOf(false) }
    var unreadOnly by remember { mutableStateOf(false) }
    var menuRow by remember { mutableStateOf<ChatRow?>(null) }

    BackHandler(enabled = search != null || showArchived) {
        if (search != null) search = null else showArchived = false
    }

    val archivedCount = rows.count { it.summary.archived }
    val q = search?.trim().orEmpty()
    val visible = rows
        .filter { it.summary.archived == showArchived }
        .filter { !unreadOnly || it.summary.unread > 0 }
        .filter {
            q.isEmpty() ||
                (it.peer?.name ?: "").contains(q, ignoreCase = true) ||
                (it.peer?.username ?: "").contains(q, ignoreCase = true)
        }
        .sortedWith(compareByDescending<ChatRow> { it.summary.pinned }.thenByDescending { it.summary.updatedAt })

    Column(Modifier.fillMaxSize()) {
        val s = search
        if (s != null) {
            Surface(color = MaterialTheme.colorScheme.surface) {
                Row(
                    Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 4.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = { search = null }) {
                        Icon(Icons.Filled.Close, contentDescription = stringResource(R.string.close))
                    }
                    OutlinedTextField(
                        value = s, onValueChange = { search = it },
                        placeholder = { Text(stringResource(R.string.search_chats)) },
                        singleLine = true,
                        shape = RoundedCornerShape(24.dp),
                        modifier = Modifier.weight(1f).padding(end = 8.dp)
                    )
                }
            }
        } else if (showArchived) {
            SubTopBar(stringResource(R.string.archived)) { showArchived = false }
        } else {
            ScreenTopBar(
                buildAnnotatedString {
                    append("Tweet ")
                    withStyle(SpanStyle(color = MaterialTheme.colorScheme.primary)) { append("me") }
                }
            ) {
                if (backend.isDemo) {
                    Text(stringResource(R.string.demo_badge), color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp)
                }
                IconButton(onClick = { search = "" }) {
                    Icon(Icons.Filled.Search, contentDescription = stringResource(R.string.search))
                }
            }
        }

        if (!showArchived && search == null) {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilterChip(
                    selected = !unreadOnly, onClick = { unreadOnly = false },
                    label = { Text(stringResource(R.string.filter_all)) }
                )
                FilterChip(
                    selected = unreadOnly, onClick = { unreadOnly = true },
                    label = { Text(stringResource(R.string.filter_unread)) }
                )
            }
        }

        Box(Modifier.weight(1f).fillMaxWidth()) {
            LazyColumn(Modifier.fillMaxSize()) {
                if (!showArchived && archivedCount > 0 && q.isEmpty()) {
                    item(key = "archived_entry") {
                        Row(
                            Modifier.fillMaxWidth().clickable { showArchived = true }.padding(horizontal = 18.dp, vertical = 14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            Icon(Icons.Outlined.Archive, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(stringResource(R.string.archived), Modifier.weight(1f), fontWeight = FontWeight.SemiBold)
                            Text(archivedCount.toString(), color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        HorizontalDivider(color = MaterialTheme.colorScheme.outline)
                    }
                }
                items(visible, key = { it.summary.id }) { row ->
                    ChatRowItem(row, me.uid, onClick = { onOpenChat(row.summary.peerUid) }, onLong = { menuRow = row })
                    HorizontalDivider(
                        modifier = Modifier.padding(start = 82.dp),
                        color = MaterialTheme.colorScheme.outline.copy(alpha = 0.6f)
                    )
                }
            }
            if (visible.isEmpty()) {
                Column(
                    Modifier.fillMaxSize().padding(32.dp),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    when {
                        q.isNotEmpty() || unreadOnly -> Text(stringResource(R.string.no_results), color = MaterialTheme.colorScheme.onSurfaceVariant)
                        showArchived -> Text(stringResource(R.string.no_archived), color = MaterialTheme.colorScheme.onSurfaceVariant)
                        archivedCount == 0 -> {
                            Text(stringResource(R.string.no_chats_title), fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(6.dp))
                            Text(
                                stringResource(R.string.no_chats_hint),
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }
            }
            FloatingActionButton(
                onClick = { showNew = true },
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary,
                shape = RoundedCornerShape(18.dp),
                modifier = Modifier.align(Alignment.BottomStart).padding(18.dp)
            ) {
                Icon(Icons.Filled.Add, contentDescription = stringResource(R.string.new_chat))
            }
        }
    }

    menuRow?.let { r ->
        ChatActions(
            summary = r.summary,
            title = r.peer?.name.orEmpty(),
            onDismiss = { menuRow = null },
            onPin = { vm.setFlag(r.summary.id, ChatFlag.PINNED, !r.summary.pinned); menuRow = null },
            onArchive = { vm.setFlag(r.summary.id, ChatFlag.ARCHIVED, !r.summary.archived); menuRow = null },
            onMute = { vm.setFlag(r.summary.id, ChatFlag.MUTED, !r.summary.muted); menuRow = null }
        )
    }

    if (showNew) {
        NewChatDialog(
            backend = backend,
            me = me.uid,
            onDismiss = { showNew = false },
            onPick = { uid -> showNew = false; onOpenChat(uid) }
        )
    }
}

@Composable
private fun ChatRowItem(row: ChatRow, meUid: String, onClick: () -> Unit, onLong: () -> Unit) {
    val ctx = LocalContext.current
    val s = row.summary
    val prefix = if (s.lastFrom == meUid || s.lastFrom == "me") stringResource(R.string.you_prefix) else ""
    val preview = prefix + when (s.lastType) {
        MsgType.IMAGE -> stringResource(R.string.msg_image)
        MsgType.VOICE -> stringResource(R.string.msg_voice)
        MsgType.TEXT -> s.lastText
    }
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .pointerInput(s.id) { detectTapGestures(onLongPress = { onLong() }, onTap = { onClick() }) }
            .padding(horizontal = 14.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Avatar(row.peer, 54.dp)
        Column(Modifier.weight(1f)) {
            Text(row.peer?.name ?: "…", fontWeight = FontWeight.SemiBold, fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.height(2.dp))
            Text(
                preview, maxLines = 1, overflow = TextOverflow.Ellipsis,
                color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 14.sp
            )
        }
        Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Text(
                listTime(ctx, s.updatedAt), fontSize = 12.sp,
                color = if (s.unread > 0 && !s.muted) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
            )
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = Alignment.CenterVertically) {
                if (s.muted) Text("🔕", fontSize = 12.sp)
                if (s.pinned) Text("📌", fontSize = 12.sp)
                if (s.unread > 0) {
                    Box(
                        Modifier.defaultMinSize(minWidth = 22.dp, minHeight = 22.dp).background(
                            if (s.muted) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.primary,
                            CircleShape
                        ).padding(horizontal = 6.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(s.unread.toString(), color = MaterialTheme.colorScheme.onPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
private fun ChatActionRow(lead: String, label: Int, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 20.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(lead, fontSize = 18.sp)
        Text(stringResource(label))
    }
}

@Composable
private fun ChatActions(
    summary: ChatSummary,
    title: String,
    onDismiss: () -> Unit,
    onPin: () -> Unit,
    onArchive: () -> Unit,
    onMute: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Surface(shape = RoundedCornerShape(20.dp), color = MaterialTheme.colorScheme.surface) {
            Column(Modifier.padding(vertical = 8.dp)) {
                Text(title, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 20.dp, vertical = 10.dp), maxLines = 1)
                HorizontalDivider(color = MaterialTheme.colorScheme.outline)
                ChatActionRow("📌", if (summary.pinned) R.string.unpin else R.string.pin, onPin)
                ChatActionRow("🗄️", if (summary.archived) R.string.unarchive else R.string.archive, onArchive)
                ChatActionRow("🔕", if (summary.muted) R.string.unmute else R.string.mute, onMute)
            }
        }
    }
}

@Composable
private fun NewChatDialog(backend: ChatBackend, me: String, onDismiss: () -> Unit, onPick: (String) -> Unit) {
    val scope = rememberCoroutineScope()
    var q by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(false) }
    var found by remember { mutableStateOf<User?>(null) }
    var msg by remember { mutableStateOf<Int?>(null) }

    fun search() {
        val name = q.trim().lowercase().removePrefix("@")
        if (name.isEmpty()) return
        loading = true
        found = null
        msg = null
        scope.launch {
            try {
                val u = backend.findUser(name)
                when {
                    u == null -> msg = R.string.user_not_found
                    u.uid == me -> msg = R.string.that_is_you
                    else -> found = u
                }
            } catch (e: Exception) {
                msg = errorRes(e.errorKind())
            } finally {
                loading = false
            }
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.new_chat)) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = q, onValueChange = { q = it },
                    label = { Text(stringResource(R.string.friend_username)) },
                    singleLine = true,
                    textStyle = MaterialTheme.typography.bodyLarge.copy(textDirection = TextDirection.Ltr),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Ascii),
                    modifier = Modifier.fillMaxWidth()
                )
                if (loading) CircularProgressIndicator(Modifier.align(Alignment.CenterHorizontally))
                msg?.let { Text(stringResource(it), color = MaterialTheme.colorScheme.onSurfaceVariant) }
                found?.let { u ->
                    Row(
                        Modifier.fillMaxWidth().clickable { onPick(u.uid) }.padding(vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Avatar(u)
                        Column {
                            Text(u.name, fontWeight = FontWeight.SemiBold)
                            Text("@${u.username}", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = { search() }) { Text(stringResource(R.string.search)) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text(stringResource(R.string.close)) } }
    )
}
