package com.tweetme.app.data

import com.tweetme.app.core.ChatFlag
import com.tweetme.app.core.ChatSummary
import com.tweetme.app.core.Draft
import com.tweetme.app.core.Message
import com.tweetme.app.core.MsgType
import com.tweetme.app.core.User
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.util.UUID

/**
 * خدمة تجريبية داخل الذاكرة تعمل بلا إنترنت (قبل إضافة google-services.json).
 * المحادثة الوحيدة مع «Tweet بوت»، وتُمسح عند إغلاق التطبيق.
 */
class DemoBackend : ChatBackend {
    override val isDemo = true

    private val bot = User("bot", "Tweet بوت", "tweetbot", about = "أنا بوت تجريبي", lastSeen = Long.MAX_VALUE / 4)
    private val chatId = "bot_me"

    override val ready: StateFlow<Boolean> = MutableStateFlow(true)
    private val _user = MutableStateFlow<User?>(User("me", "ضيف", "guest", about = "مرحباً! أنا أستخدم Tweet me"))
    override val currentUser: StateFlow<User?> = _user

    private val msgs = MutableStateFlow<Map<String, List<Message>>>(emptyMap())
    private val unread = MutableStateFlow<Map<String, Int>>(emptyMap())
    private val flags = MutableStateFlow<Map<String, Set<ChatFlag>>>(emptyMap())
    private val blockedSet = MutableStateFlow<Set<String>>(emptySet())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    init {
        post(
            "bot",
            Draft(
                MsgType.TEXT,
                "أهلاً بك في Tweet me! 👋\nهذا وضع تجريبي على هاتفك فقط. بعد إضافة ملف google-services.json تتحول المراسلة إلى حقيقية بين الأعضاء."
            )
        )
    }

    private fun post(from: String, d: Draft) {
        val m = Message(
            id = UUID.randomUUID().toString(), from = from, type = d.type, text = d.text, url = d.url,
            durSec = d.durSec, at = System.currentTimeMillis(),
            replyToId = d.replyToId, replyText = d.replyText, replyFrom = d.replyFrom
        )
        msgs.update { cur -> cur + (chatId to (cur[chatId].orEmpty() + m)) }
        if (from != "me") unread.update { cur -> cur + (chatId to ((cur[chatId] ?: 0) + 1)) }
    }

    private fun mutate(id: String, f: (Message) -> Message) {
        msgs.update { cur -> cur + (chatId to cur[chatId].orEmpty().map { if (it.id == id) f(it) else it }) }
    }

    override fun currentEmail(): String = "guest@demo.local"

    override suspend fun signUp(name: String, username: String, email: String, password: String) {
        _user.value = User("me", name, username)
    }

    override suspend fun signIn(email: String, password: String) {
        _user.value = _user.value ?: User("me", "ضيف", "guest")
    }

    override suspend fun resetPassword(email: String) {}

    override fun signOut() {
        _user.value = null
    }

    override suspend fun deleteAccount(me: String, password: String) {
        _user.value = null
    }

    override suspend fun findUser(username: String): User? = if (username == bot.username) bot else null

    override suspend fun getUser(uid: String): User = if (uid == bot.uid) bot else _user.value ?: User("me", "ضيف", "guest")

    override fun watchUser(uid: String): Flow<User?> = _user.map { u -> if (uid == bot.uid) bot else u }

    override suspend fun updateProfile(me: String, name: String, about: String) {
        _user.update { it?.copy(name = name, about = about) }
    }

    override suspend fun setPhoto(me: String, dataUri: String) {
        _user.update { it?.copy(photo = dataUri) }
    }

    override suspend fun setPrivacy(me: String, showLastSeen: Boolean, showReceipts: Boolean) {
        _user.update { it?.copy(showLastSeen = showLastSeen, showReceipts = showReceipts) }
    }

    override suspend fun heartbeat(me: String) {}

    override fun blocked(me: String): Flow<Set<String>> = blockedSet

    override suspend fun block(me: String, uid: String) {
        blockedSet.update { it + uid }
    }

    override suspend fun unblock(me: String, uid: String) {
        blockedSet.update { it - uid }
    }

    override fun chats(me: String): Flow<List<ChatSummary>> = combine(msgs, unread, flags) { m, u, f ->
        m.map { (id, list) ->
            val last = list.last()
            val fl = f[id].orEmpty()
            ChatSummary(
                id, bot.uid, last.type, last.text, last.from, last.at, u[id] ?: 0, Long.MAX_VALUE,
                pinned = ChatFlag.PINNED in fl, archived = ChatFlag.ARCHIVED in fl, muted = ChatFlag.MUTED in fl
            )
        }
    }

    override suspend fun setChatFlag(chatId: String, me: String, flag: ChatFlag, value: Boolean) {
        flags.update { cur ->
            val set = cur[chatId].orEmpty()
            cur + (chatId to (if (value) set + flag else set - flag))
        }
    }

    override suspend fun setTyping(chatId: String, me: String) {}

    override fun messages(chatId: String): Flow<List<Message>> = msgs.map { it[chatId].orEmpty() }

    override suspend fun send(chatId: String, me: String, peerUid: String, draft: Draft) {
        post("me", draft)
        scope.launch {
            delay(800)
            val reply = when (draft.type) {
                MsgType.TEXT -> "وصلتني رسالتك: «${draft.text.take(80)}»"
                MsgType.IMAGE -> "وصلتني الصورة 📷"
                MsgType.VOICE -> "وصلتني رسالتك الصوتية 🎤"
            }
            post("bot", Draft(MsgType.TEXT, reply))
        }
    }

    override suspend fun markRead(chatId: String, me: String) {
        unread.update { it + (chatId to 0) }
    }

    override suspend fun react(chatId: String, msgId: String, me: String, emoji: String?) {
        mutate(msgId) { m ->
            m.copy(reactions = if (emoji == null) m.reactions - me else m.reactions + (me to emoji))
        }
    }

    override suspend fun deleteForMe(chatId: String, msgId: String, me: String) {
        mutate(msgId) { it.copy(hiddenFor = it.hiddenFor + me) }
    }

    override suspend fun deleteForEveryone(chatId: String, msgId: String) {
        mutate(msgId) { it.copy(deleted = true, text = "", url = "") }
    }

    override suspend fun editMessage(chatId: String, msgId: String, text: String) {
        mutate(msgId) { it.copy(text = text, edited = true) }
    }
}
