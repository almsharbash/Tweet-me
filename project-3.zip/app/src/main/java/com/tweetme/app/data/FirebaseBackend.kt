package com.tweetme.app.data

import com.google.firebase.FirebaseNetworkException
import com.google.firebase.FirebaseTooManyRequestsException
import com.google.firebase.Timestamp
import com.google.firebase.auth.EmailAuthProvider
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException
import com.google.firebase.auth.FirebaseAuthInvalidUserException
import com.google.firebase.auth.FirebaseAuthUserCollisionException
import com.google.firebase.auth.FirebaseAuthWeakPasswordException
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.MetadataChanges
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.SetOptions
import com.google.firebase.firestore.Source
import com.google.firebase.firestore.Transaction
import com.tweetme.app.core.AppError
import com.tweetme.app.core.ChatFlag
import com.tweetme.app.core.ChatSummary
import com.tweetme.app.core.Draft
import com.tweetme.app.core.ErrorKind
import com.tweetme.app.core.Message
import com.tweetme.app.core.MsgType
import com.tweetme.app.core.User
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import java.util.concurrent.ConcurrentHashMap

/**
 * التنفيذ الحقيقي على Firebase (Auth + Firestore).
 * هيكل البيانات:
 *   users/{uid}                 name, username, about, photo, lastSeen, showLastSeen, showReceipts
 *   users/{uid}/blocked/{uid2}  المحظورون
 *   usernames/{username}        { uid } لضمان تفرّد الاسم
 *   chats/{uidA_uidB}           members, last, updatedAt, unread{uid}, lastRead{uid},
 *                               typing{uid}, pinned{uid}, archived{uid}, muted{uid}
 *   chats/{id}/messages/{mid}   from, type, text, url, dur, at, reply*, deleted, edited, reactions{uid}, hiddenFor[]
 */
class FirebaseBackend : ChatBackend {
    override val isDemo = false

    private val auth = FirebaseAuth.getInstance()
    private val db = FirebaseFirestore.getInstance()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val cache = ConcurrentHashMap<String, User>()
    private var selfReg: ListenerRegistration? = null

    @Volatile
    private var busy = false

    private val _ready = MutableStateFlow(false)
    override val ready: StateFlow<Boolean> = _ready
    private val _user = MutableStateFlow<User?>(null)
    override val currentUser: StateFlow<User?> = _user

    init {
        auth.addAuthStateListener { fa ->
            val fu = fa.currentUser
            if (fu == null) {
                selfReg?.remove()
                selfReg = null
                _user.value = null
                _ready.value = true
            } else if (!busy) {
                scope.launch {
                    val u = loadProfile(fu.uid)
                    _user.value = u
                    if (u != null) attachSelf(fu.uid)
                    _ready.value = true
                }
            }
        }
    }

    private fun userRef(uid: String) = db.collection("users").document(uid)
    private fun chatRef(id: String) = db.collection("chats").document(id)
    private fun msgRef(chatId: String, msgId: String) = chatRef(chatId).collection("messages").document(msgId)

    /** يتابع ملف العضو الحالي ليتحدث فوراً عند أي تعديل (اسم، صورة، خصوصية). */
    private fun attachSelf(uid: String) {
        selfReg?.remove()
        selfReg = userRef(uid).addSnapshotListener { snap, _ ->
            if (snap != null && snap.exists()) {
                val u = snap.toUser(uid)
                cache[uid] = u
                _user.value = u
            }
        }
    }

    private suspend fun loadProfile(uid: String): User? {
        val ref = userRef(uid)
        val snap = try {
            ref.get().await()
        } catch (e: Exception) {
            try {
                ref.get(Source.CACHE).await()
            } catch (e2: Exception) {
                null
            }
        }
        if (snap == null) {
            // بلا إنترنت وبلا نسخة محفوظة: نسمح بالدخول بمعلومات أساسية
            return User(uid, auth.currentUser?.email?.substringBefore('@').orEmpty(), "")
        }
        if (!snap.exists()) {
            auth.signOut()
            return null
        }
        return snap.toUser(uid).also { cache[uid] = it }
    }

    override fun currentEmail(): String = auth.currentUser?.email.orEmpty()

    // ---------- الحساب ----------

    override suspend fun signUp(name: String, username: String, email: String, password: String) = wrap {
        busy = true
        try {
            val res = auth.createUserWithEmailAndPassword(email, password).await()
            val fu = res.user ?: throw AppError(ErrorKind.UNKNOWN)
            val uid = fu.uid
            try {
                val ok = db.runTransaction(Transaction.Function<Boolean> { tx ->
                    val uref = db.collection("usernames").document(username)
                    if (tx.get(uref).exists()) {
                        false
                    } else {
                        tx.set(uref, mapOf("uid" to uid))
                        tx.set(
                            userRef(uid),
                            mapOf(
                                "name" to name, "username" to username, "about" to "",
                                "showLastSeen" to true, "showReceipts" to true,
                                "createdAt" to FieldValue.serverTimestamp()
                            )
                        )
                        true
                    }
                }).await()
                if (!ok) throw AppError(ErrorKind.USERNAME_TAKEN)
            } catch (e: Exception) {
                runCatching { fu.delete().await() }
                throw e
            }
            val me = User(uid, name, username)
            cache[uid] = me
            _user.value = me
            _ready.value = true
            attachSelf(uid)
            runCatching { fu.sendEmailVerification() }
            Unit
        } finally {
            busy = false
        }
    }

    override suspend fun signIn(email: String, password: String) = wrap {
        auth.signInWithEmailAndPassword(email, password).await()
        Unit
    }

    override suspend fun resetPassword(email: String) = wrap {
        auth.sendPasswordResetEmail(email).await()
        Unit
    }

    override fun signOut() {
        auth.signOut()
    }

    override suspend fun deleteAccount(me: String, password: String) = wrap {
        val fu = auth.currentUser ?: throw AppError(ErrorKind.UNKNOWN)
        val email = fu.email ?: throw AppError(ErrorKind.UNKNOWN)
        val username = _user.value?.username.orEmpty()
        // نتحقق من كلمة المرور أولاً؛ إن كانت خاطئة لا نمسّ شيئاً
        fu.reauthenticate(EmailAuthProvider.getCredential(email, password)).await()
        selfReg?.remove()
        selfReg = null
        if (username.isNotEmpty()) runCatching { db.collection("usernames").document(username).delete().await() }
        runCatching { userRef(me).delete().await() }
        fu.delete().await()
        Unit
    }

    // ---------- الأعضاء والملف الشخصي ----------

    override suspend fun findUser(username: String): User? = wrap {
        val s = db.collection("usernames").document(username).get().await()
        val uid = s.getString("uid")
        if (!s.exists() || uid == null) null else getUser(uid)
    }

    override suspend fun getUser(uid: String): User = cache[uid] ?: wrap {
        val s = userRef(uid).get().await()
        val u = if (s.exists()) s.toUser(uid) else User(uid, "مستخدم", "")
        cache[uid] = u
        u
    }

    override fun watchUser(uid: String): Flow<User?> = callbackFlow {
        val reg = userRef(uid).addSnapshotListener { snap, e ->
            if (e != null) {
                trySend(null)
            } else if (snap != null && snap.exists()) {
                val u = snap.toUser(uid)
                cache[uid] = u
                trySend(u)
            } else {
                trySend(null)
            }
        }
        awaitClose { reg.remove() }
    }

    override suspend fun updateProfile(me: String, name: String, about: String) = wrap {
        userRef(me).update(mapOf<String, Any>("name" to name, "about" to about)).await()
        Unit
    }

    override suspend fun setPhoto(me: String, dataUri: String) = wrap {
        userRef(me).update("photo", dataUri).await()
        Unit
    }

    override suspend fun setPrivacy(me: String, showLastSeen: Boolean, showReceipts: Boolean) = wrap {
        userRef(me).update(mapOf<String, Any>("showLastSeen" to showLastSeen, "showReceipts" to showReceipts)).await()
        Unit
    }

    override suspend fun heartbeat(me: String) {
        runCatching { userRef(me).update("lastSeen", FieldValue.serverTimestamp()).await() }
    }

    // ---------- الحظر ----------

    override fun blocked(me: String): Flow<Set<String>> = callbackFlow {
        val reg = userRef(me).collection("blocked").addSnapshotListener { snap, e ->
            if (e != null || snap == null) {
                trySend(emptySet())
            } else {
                trySend(snap.documents.map { it.id }.toSet())
            }
        }
        awaitClose { reg.remove() }
    }

    override suspend fun block(me: String, uid: String) = wrap {
        userRef(me).collection("blocked").document(uid).set(mapOf("at" to FieldValue.serverTimestamp())).await()
        Unit
    }

    override suspend fun unblock(me: String, uid: String) = wrap {
        userRef(me).collection("blocked").document(uid).delete().await()
        Unit
    }

    // ---------- المحادثات ----------

    override fun chats(me: String): Flow<List<ChatSummary>> = callbackFlow {
        val reg = db.collection("chats").whereArrayContains("members", me)
            .addSnapshotListener { snap, e ->
                if (e != null || snap == null) {
                    trySend(emptyList())
                    close()
                    return@addSnapshotListener
                }
                trySend(snap.documents.mapNotNull { it.toSummary(me) })
            }
        awaitClose { reg.remove() }
    }

    override suspend fun setChatFlag(chatId: String, me: String, flag: ChatFlag, value: Boolean) = wrap {
        chatRef(chatId).update("${flag.key}.$me", value).await()
        Unit
    }

    override suspend fun setTyping(chatId: String, me: String) {
        runCatching { chatRef(chatId).update("typing.$me", FieldValue.serverTimestamp()).await() }
    }

    // ---------- الرسائل ----------

    override fun messages(chatId: String): Flow<List<Message>> = callbackFlow {
        val reg = chatRef(chatId).collection("messages")
            .orderBy("at", Query.Direction.DESCENDING).limit(150)
            .addSnapshotListener(MetadataChanges.INCLUDE) { snap, e ->
                if (e != null || snap == null) {
                    trySend(emptyList())
                    close()
                    return@addSnapshotListener
                }
                trySend(snap.documents.mapNotNull { it.toMessage() }.reversed())
            }
        awaitClose { reg.remove() }
    }

    override suspend fun send(chatId: String, me: String, peerUid: String, draft: Draft) = wrap {
        val receipts = _user.value?.showReceipts != false
        val chatData = mutableMapOf<String, Any>(
            "members" to listOf(me, peerUid).sorted(),
            "last" to mapOf("type" to draft.type.wire, "text" to draft.text, "from" to me),
            "updatedAt" to FieldValue.serverTimestamp(),
            "unread" to mapOf(peerUid to FieldValue.increment(1))
        )
        if (receipts) chatData["lastRead"] = mapOf(me to FieldValue.serverTimestamp())

        val batch = db.batch()
        batch.set(chatRef(chatId), chatData, SetOptions.merge())
        batch.set(
            chatRef(chatId).collection("messages").document(),
            mapOf(
                "from" to me,
                "type" to draft.type.wire,
                "text" to draft.text,
                "url" to draft.url,
                "dur" to draft.durSec,
                "replyToId" to draft.replyToId,
                "replyText" to draft.replyText,
                "replyFrom" to draft.replyFrom,
                "at" to FieldValue.serverTimestamp()
            )
        )
        batch.commit().await()
        Unit
    }

    override suspend fun markRead(chatId: String, me: String) {
        val receipts = _user.value?.showReceipts != false
        val upd = mutableMapOf<String, Any>("unread.$me" to 0)
        if (receipts) upd["lastRead.$me"] = FieldValue.serverTimestamp()
        // قد لا توجد المحادثة بعد، فنتجاهل الفشل
        runCatching { chatRef(chatId).update(upd).await() }
    }

    override suspend fun react(chatId: String, msgId: String, me: String, emoji: String?) = wrap {
        msgRef(chatId, msgId).update("reactions.$me", emoji ?: FieldValue.delete()).await()
        Unit
    }

    override suspend fun deleteForMe(chatId: String, msgId: String, me: String) = wrap {
        msgRef(chatId, msgId).update("hiddenFor", FieldValue.arrayUnion(me)).await()
        Unit
    }

    override suspend fun deleteForEveryone(chatId: String, msgId: String) = wrap {
        msgRef(chatId, msgId).update(mapOf<String, Any>("deleted" to true, "text" to "", "url" to "")).await()
        Unit
    }

    override suspend fun editMessage(chatId: String, msgId: String, text: String) = wrap {
        msgRef(chatId, msgId).update(mapOf<String, Any>("text" to text, "edited" to true)).await()
        Unit
    }

    // ---------- أدوات داخلية ----------

    private fun Any?.millis(): Long = (this as? Timestamp)?.toDate()?.time ?: 0L

    private fun DocumentSnapshot.toUser(uid: String) = User(
        uid = uid,
        name = getString("name").orEmpty(),
        username = getString("username").orEmpty(),
        about = getString("about").orEmpty(),
        photo = getString("photo").orEmpty(),
        lastSeen = getTimestamp("lastSeen")?.toDate()?.time ?: 0L,
        showLastSeen = getBoolean("showLastSeen") ?: true,
        showReceipts = getBoolean("showReceipts") ?: true
    )

    private fun Map<*, *>.flag(key: String, uid: String): Boolean = (this[key] as? Map<*, *>)?.get(uid) == true

    private fun DocumentSnapshot.toSummary(me: String): ChatSummary? {
        val data = getData(DocumentSnapshot.ServerTimestampBehavior.ESTIMATE) ?: return null
        val members = (data["members"] as? List<*>)?.filterIsInstance<String>() ?: return null
        val peer = members.firstOrNull { it != me } ?: return null
        val last = data["last"] as? Map<*, *>
        val unread = ((data["unread"] as? Map<*, *>)?.get(me) as? Number)?.toInt() ?: 0
        val peerRead = (data["lastRead"] as? Map<*, *>)?.get(peer).millis()
        val typing = (data["typing"] as? Map<*, *>)?.get(peer).millis()
        return ChatSummary(
            id = id,
            peerUid = peer,
            lastType = MsgType.from(last?.get("type") as? String),
            lastText = last?.get("text") as? String ?: "",
            lastFrom = last?.get("from") as? String ?: "",
            updatedAt = data["updatedAt"].millis().takeIf { it > 0 } ?: System.currentTimeMillis(),
            unread = unread,
            peerReadAt = peerRead,
            pinned = data.flag("pinned", me),
            archived = data.flag("archived", me),
            muted = data.flag("muted", me),
            peerTypingAt = typing
        )
    }

    private fun DocumentSnapshot.toMessage(): Message? {
        val m = getData(DocumentSnapshot.ServerTimestampBehavior.ESTIMATE) ?: return null
        val reactions = (m["reactions"] as? Map<*, *>)
            ?.mapNotNull { (k, v) -> if (k is String && v is String) k to v else null }
            ?.toMap().orEmpty()
        return Message(
            id = id,
            from = m["from"] as? String ?: "",
            type = MsgType.from(m["type"] as? String),
            text = m["text"] as? String ?: "",
            url = m["url"] as? String ?: "",
            durSec = (m["dur"] as? Number)?.toInt() ?: 0,
            at = m["at"].millis().takeIf { it > 0 } ?: System.currentTimeMillis(),
            pending = metadata.hasPendingWrites(),
            replyToId = m["replyToId"] as? String ?: "",
            replyText = m["replyText"] as? String ?: "",
            replyFrom = m["replyFrom"] as? String ?: "",
            deleted = m["deleted"] as? Boolean ?: false,
            edited = m["edited"] as? Boolean ?: false,
            reactions = reactions,
            hiddenFor = (m["hiddenFor"] as? List<*>)?.filterIsInstance<String>().orEmpty()
        )
    }

    private inline fun <T> wrap(block: () -> T): T = try {
        block()
    } catch (e: AppError) {
        throw e
    } catch (e: CancellationException) {
        throw e
    } catch (e: Exception) {
        throw e.toApp()
    }

    private fun Throwable.toApp(): AppError = AppError(
        when (this) {
            is FirebaseAuthWeakPasswordException -> ErrorKind.WEAK_PASSWORD
            is FirebaseAuthUserCollisionException -> ErrorKind.EMAIL_IN_USE
            is FirebaseAuthInvalidCredentialsException ->
                if (errorCode == "ERROR_INVALID_EMAIL") ErrorKind.INVALID_EMAIL else ErrorKind.BAD_CREDENTIALS
            is FirebaseAuthInvalidUserException -> ErrorKind.BAD_CREDENTIALS
            is FirebaseNetworkException -> ErrorKind.NETWORK
            is FirebaseTooManyRequestsException -> ErrorKind.TOO_MANY
            is FirebaseFirestoreException -> when (code) {
                FirebaseFirestoreException.Code.PERMISSION_DENIED -> ErrorKind.PERMISSION
                FirebaseFirestoreException.Code.UNAVAILABLE -> ErrorKind.NETWORK
                else -> ErrorKind.UNKNOWN
            }
            else -> ErrorKind.UNKNOWN
        },
        this
    )
}
