package com.tweetme.app.data

import com.tweetme.app.core.ChatFlag
import com.tweetme.app.core.ChatSummary
import com.tweetme.app.core.Draft
import com.tweetme.app.core.Message
import com.tweetme.app.core.User
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.StateFlow

/**
 * العقد الوحيد بين الواجهة والخدمة الخلفية.
 * لإضافة خدمة جديدة (مجموعات، حالات، مكالمات...) أضف دوالها هنا ثم نفّذها في
 * FirebaseBackend وDemoBackend، ولا تلمس الواجهة قبل ذلك.
 * كل الأخطاء تُرمى كـ AppError.
 */
interface ChatBackend {
    val isDemo: Boolean

    /** true بعد معرفة حالة الدخول (مسجّل أو لا). */
    val ready: StateFlow<Boolean>

    /** العضو الحالي (يتحدّث تلقائياً عند تعديل ملفه)، أو null إذا لم يسجّل الدخول. */
    val currentUser: StateFlow<User?>

    fun currentEmail(): String

    // ---------- الحساب ----------
    suspend fun signUp(name: String, username: String, email: String, password: String)
    suspend fun signIn(email: String, password: String)
    suspend fun resetPassword(email: String)
    fun signOut()
    suspend fun deleteAccount(me: String, password: String)

    // ---------- الأعضاء والملف الشخصي ----------
    suspend fun findUser(username: String): User?
    suspend fun getUser(uid: String): User
    fun watchUser(uid: String): Flow<User?>
    suspend fun updateProfile(me: String, name: String, about: String)
    suspend fun setPhoto(me: String, dataUri: String)
    suspend fun setPrivacy(me: String, showLastSeen: Boolean, showReceipts: Boolean)
    suspend fun heartbeat(me: String)

    // ---------- الحظر ----------
    fun blocked(me: String): Flow<Set<String>>
    suspend fun block(me: String, uid: String)
    suspend fun unblock(me: String, uid: String)

    // ---------- المحادثات ----------
    fun chats(me: String): Flow<List<ChatSummary>>
    suspend fun setChatFlag(chatId: String, me: String, flag: ChatFlag, value: Boolean)
    suspend fun setTyping(chatId: String, me: String)

    // ---------- الرسائل ----------
    fun messages(chatId: String): Flow<List<Message>>
    suspend fun send(chatId: String, me: String, peerUid: String, draft: Draft)
    suspend fun markRead(chatId: String, me: String)
    suspend fun react(chatId: String, msgId: String, me: String, emoji: String?)
    suspend fun deleteForMe(chatId: String, msgId: String, me: String)
    suspend fun deleteForEveryone(chatId: String, msgId: String)
    suspend fun editMessage(chatId: String, msgId: String, text: String)
}
