package com.tweetme.app.ui

import android.Manifest
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Call
import androidx.compose.material.icons.outlined.Chat
import androidx.compose.material.icons.outlined.DonutLarge
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.key
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.tweetme.app.AppContainer
import com.tweetme.app.R
import com.tweetme.app.core.User
import com.tweetme.app.data.AppPrefs
import com.tweetme.app.ui.auth.AuthScreen
import com.tweetme.app.ui.chat.ChatScreen
import com.tweetme.app.ui.chat.ChatViewModel
import com.tweetme.app.ui.chats.ChatListScreen
import com.tweetme.app.ui.chats.ChatListViewModel
import com.tweetme.app.ui.common.SoonScreen
import com.tweetme.app.core.MsgType
import com.tweetme.app.notify.Sounds
import com.tweetme.app.ui.settings.AccountScreen
import com.tweetme.app.ui.settings.BlockedScreen
import com.tweetme.app.ui.settings.ChatsSettingsScreen
import com.tweetme.app.ui.settings.HelpScreen
import com.tweetme.app.ui.settings.NotificationsSettingsScreen
import com.tweetme.app.ui.settings.PrivacyScreen
import com.tweetme.app.ui.settings.ProfileScreen
import com.tweetme.app.ui.settings.SettingsRoutes
import com.tweetme.app.ui.settings.SettingsScreen
import com.tweetme.app.ui.settings.StorageScreen

private const val ROUTE_CHATS = "chats"
private const val ROUTE_STATUS = "status"
private const val ROUTE_CALLS = "calls"
private const val ROUTE_CHAT = "chat/{uid}"

private data class Tab(val route: String, val label: Int, val icon: ImageVector)

/** نقطة التنقل الرئيسية: شاشة التحميل ← الدخول ← التطبيق. لإضافة شاشة جديدة أضف route هنا. */
@Composable
fun AppNav(container: AppContainer, prefs: AppPrefs) {
    val ready by container.backend.ready.collectAsState()
    val user by container.backend.currentUser.collectAsState()
    val me = user
    when {
        !ready -> Box(
            Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background),
            contentAlignment = Alignment.Center
        ) { CircularProgressIndicator() }

        me == null -> AuthScreen(container.backend)

        else -> key(me.uid) { SignedIn(container, prefs, me) }
    }
}

@Composable
private fun SignedIn(c: AppContainer, prefs: AppPrefs, me: User) {
    val nav = rememberNavController()
    val entry by nav.currentBackStackEntryAsState()
    val route = entry?.destination?.route
    val tabs = listOf(
        Tab(ROUTE_CHATS, R.string.tab_chats, Icons.Outlined.Chat),
        Tab(ROUTE_STATUS, R.string.tab_status, Icons.Outlined.DonutLarge),
        Tab(ROUTE_CALLS, R.string.tab_calls, Icons.Outlined.Call),
        Tab(SettingsRoutes.HOME, R.string.tab_settings, Icons.Outlined.Settings)
    )

    var totalUnread by androidx.compose.runtime.remember { mutableIntStateOf(0) }
    val prefsNow by rememberUpdatedState(prefs)
    val openChatUid by rememberUpdatedState(if (route == ROUTE_CHAT) entry?.arguments?.getString("uid") else null)

    val askNotif = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33 && !c.notifier.canNotify()) askNotif.launch(Manifest.permission.POST_NOTIFICATIONS)
    }

    // تنبيه عند وصول رسالة جديدة: إشعار نظام في الخلفية، وصوت قصير في المقدمة
    LaunchedEffect(me.uid) {
        var known: Map<String, Int>? = null
        c.backend.chats(me.uid).collect { list ->
            totalUnread = list.filter { !it.archived && !it.muted }.sumOf { it.unread }
            val before = known
            known = list.associate { it.id to it.unread }
            if (before == null) return@collect
            list.filter { it.unread > (before[it.id] ?: 0) && !it.muted && it.lastFrom != me.uid }.forEach { s ->
                if (c.inForeground) {
                    if (prefsNow.sounds && openChatUid != s.peerUid) Sounds.ping(c.context)
                } else if (prefsNow.notify) {
                    val title = runCatching { c.backend.getUser(s.peerUid).name }.getOrDefault(c.context.getString(R.string.app_name))
                    val body = when (s.lastType) {
                        MsgType.TEXT -> s.lastText
                        MsgType.IMAGE -> c.context.getString(R.string.msg_image)
                        MsgType.VOICE -> c.context.getString(R.string.msg_voice)
                    }
                    c.notifier.message(s.id, title, body)
                }
            }
        }
    }

    Scaffold(
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        bottomBar = {
            if (tabs.any { it.route == route }) {
                NavigationBar {
                    tabs.forEach { t ->
                        NavigationBarItem(
                            selected = route == t.route,
                            onClick = {
                                nav.navigate(t.route) {
                                    popUpTo(ROUTE_CHATS) { saveState = true }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            },
                            colors = NavigationBarItemDefaults.colors(
                                indicatorColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.25f)
                            ),
                            icon = {
                                if (t.route == ROUTE_CHATS && totalUnread > 0) {
                                    BadgedBox(badge = { Badge { Text(if (totalUnread > 99) "99+" else totalUnread.toString()) } }) {
                                        Icon(t.icon, contentDescription = null)
                                    }
                                } else {
                                    Icon(t.icon, contentDescription = null)
                                }
                            },
                            label = { Text(stringResource(t.label)) }
                        )
                    }
                }
            }
        }
    ) { pad ->
        NavHost(nav, startDestination = ROUTE_CHATS, modifier = Modifier.padding(pad)) {
            composable(ROUTE_CHATS) {
                val vm: ChatListViewModel = viewModel(
                    factory = viewModelFactory { initializer { ChatListViewModel(c.backend, me.uid) } }
                )
                ChatListScreen(vm, c.backend, me) { uid -> nav.navigate("chat/$uid") }
            }
            composable(ROUTE_STATUS) { SoonScreen(R.string.tab_status) }
            composable(ROUTE_CALLS) { SoonScreen(R.string.tab_calls) }
            composable(SettingsRoutes.HOME) { SettingsScreen(me, c.backend) { nav.navigate(it) } }
            composable(SettingsRoutes.PROFILE) { ProfileScreen(me, c.backend) { nav.popBackStack() } }
            composable(SettingsRoutes.ACCOUNT) { AccountScreen(me, c.backend) { nav.popBackStack() } }
            composable(SettingsRoutes.PRIVACY) {
                PrivacyScreen(me, c.backend, { nav.popBackStack() }) { nav.navigate(SettingsRoutes.BLOCKED) }
            }
            composable(SettingsRoutes.BLOCKED) { BlockedScreen(me, c.backend) { nav.popBackStack() } }
            composable(SettingsRoutes.CHATS) { ChatsSettingsScreen(prefs, c.prefs) { nav.popBackStack() } }
            composable(SettingsRoutes.NOTIFICATIONS) { NotificationsSettingsScreen(prefs, c.prefs) { nav.popBackStack() } }
            composable(SettingsRoutes.STORAGE) { StorageScreen(prefs, c.prefs) { nav.popBackStack() } }
            composable(SettingsRoutes.HELP) { HelpScreen { nav.popBackStack() } }
            composable(ROUTE_CHAT, arguments = listOf(navArgument("uid") { type = NavType.StringType })) { e ->
                val uid = e.arguments?.getString("uid").orEmpty()
                val vm: ChatViewModel = viewModel(
                    key = "chat_$uid",
                    factory = viewModelFactory { initializer { ChatViewModel(c.context, c.backend, me.uid, uid) } }
                )
                ChatScreen(
                    vm, me, c.player, prefs,
                    onBack = { nav.popBackStack() },
                    onOpenSettings = { nav.navigate(SettingsRoutes.CHATS) }
                )
            }
        }
    }
}
