package com.tweetme.app.ui.settings

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.Email
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.Notifications
import androidx.compose.material.icons.outlined.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tweetme.app.R
import com.tweetme.app.core.User
import com.tweetme.app.core.errorKind
import com.tweetme.app.core.errorRes
import com.tweetme.app.data.AppPrefs
import com.tweetme.app.data.ChatBackend
import com.tweetme.app.data.PrefsStore
import com.tweetme.app.ui.common.SubTopBar
import com.tweetme.app.ui.theme.BG_IMAGE_ID
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

/** الإشعارات: تشغيل الإشعارات والأصوات وإذن النظام. */
@Composable
fun NotificationsSettingsScreen(prefs: AppPrefs, store: PrefsStore, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val askPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }

    Column(Modifier.fillMaxSize()) {
        SubTopBar(stringResource(R.string.set_notifications), onBack)
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
            SectionTitle(R.string.sec_messages)
            SwitchRow(R.string.notif_show, R.string.notif_show_hint, prefs.notify) { on ->
                scope.launch { store.setNotify(on) }
                if (on && Build.VERSION.SDK_INT >= 33) askPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
            SwitchRow(R.string.notif_sound, R.string.notif_sound_hint, prefs.sounds) { scope.launch { store.setSounds(it) } }
            SectionTitle(R.string.sec_system)
            SettingRow(Icons.Outlined.Notifications, R.string.notif_system, R.string.notif_system_hint) {
                val i = Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                    .putExtra(Settings.EXTRA_APP_PACKAGE, ctx.packageName)
                runCatching { ctx.startActivity(i) }
            }
            Text(
                stringResource(R.string.notif_note),
                color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp,
                modifier = Modifier.padding(horizontal = 18.dp, vertical = 16.dp)
            )
        }
    }
}

/** التخزين: حجم الملفات المؤقتة وتنظيفها وإعادة الخلفية الافتراضية. */
@Composable
fun StorageScreen(prefs: AppPrefs, store: PrefsStore, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var size by remember { mutableStateOf(-1L) }
    var tick by remember { mutableStateOf(0) }

    androidx.compose.runtime.LaunchedEffect(tick) {
        size = withContext(Dispatchers.IO) { dirSize(ctx.cacheDir) }
    }

    Column(Modifier.fillMaxSize()) {
        SubTopBar(stringResource(R.string.set_storage), onBack)
        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text(
                if (size < 0) "…" else stringResource(R.string.storage_cache, formatSize(size)),
                fontSize = 16.sp
            )
            OutlinedButton(
                onClick = {
                    scope.launch {
                        withContext(Dispatchers.IO) { ctx.cacheDir.listFiles()?.forEach { it.deleteRecursively() } }
                        tick++
                        Toast.makeText(ctx, R.string.saved, Toast.LENGTH_SHORT).show()
                    }
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text(stringResource(R.string.storage_clear)) }
            if (prefs.bgId == BG_IMAGE_ID) {
                OutlinedButton(
                    onClick = {
                        scope.launch {
                            withContext(Dispatchers.IO) { File(ctx.filesDir, "chat_bg.jpg").delete() }
                            store.setBackground("default")
                        }
                    },
                    modifier = Modifier.fillMaxWidth()
                ) { Text(stringResource(R.string.storage_reset_bg)) }
            }
            Text(
                stringResource(R.string.storage_note),
                color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp
            )
        }
    }
}

private fun dirSize(f: File): Long =
    if (f.isFile) f.length() else f.listFiles()?.sumOf { dirSize(it) } ?: 0L

private fun formatSize(b: Long): String = when {
    b < 1024 -> "$b B"
    b < 1024 * 1024 -> String.format(java.util.Locale.US, "%.1f KB", b / 1024.0)
    else -> String.format(java.util.Locale.US, "%.1f MB", b / 1024.0 / 1024.0)
}

/** الحساب: البريد، تغيير كلمة المرور برابط، وحذف الحساب نهائياً. */
@Composable
fun AccountScreen(me: User, backend: ChatBackend, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var askDelete by remember { mutableStateOf(false) }
    var password by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    val email = remember { backend.currentEmail() }

    fun toast(res: Int) = Toast.makeText(ctx, res, Toast.LENGTH_SHORT).show()

    Column(Modifier.fillMaxSize()) {
        SubTopBar(stringResource(R.string.set_account), onBack)
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
            SettingRow(
                Icons.Outlined.Email, R.string.acc_email,
                if (email.isBlank()) R.string.acc_email_demo else R.string.acc_email_hint
            )
            if (email.isNotBlank()) {
                Text(
                    email, modifier = Modifier.padding(start = 60.dp, end = 18.dp, bottom = 10.dp),
                    color = MaterialTheme.colorScheme.primary, fontSize = 14.sp
                )
            }
            SettingRow(Icons.Outlined.Share, R.string.acc_change_password, R.string.acc_change_password_hint) {
                if (email.isBlank()) {
                    toast(R.string.acc_email_demo)
                } else {
                    scope.launch {
                        try {
                            backend.resetPassword(email)
                            toast(R.string.info_reset_sent)
                        } catch (e: Exception) {
                            toast(errorRes(e.errorKind()))
                        }
                    }
                }
            }
            SettingRow(Icons.Outlined.Delete, R.string.acc_delete, R.string.acc_delete_hint) { askDelete = true }
        }
    }

    if (askDelete) {
        AlertDialog(
            onDismissRequest = { if (!busy) askDelete = false },
            title = { Text(stringResource(R.string.acc_delete_title)) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(stringResource(R.string.acc_delete_warn))
                    if (!backend.isDemo) {
                        OutlinedTextField(
                            value = password, onValueChange = { password = it },
                            label = { Text(stringResource(R.string.f_password)) },
                            singleLine = true,
                            visualTransformation = PasswordVisualTransformation(),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password)
                        )
                    }
                }
            },
            confirmButton = {
                TextButton(
                    enabled = !busy && (backend.isDemo || password.isNotEmpty()),
                    onClick = {
                        scope.launch {
                            busy = true
                            try {
                                backend.deleteAccount(me.uid, password)
                            } catch (e: Exception) {
                                toast(errorRes(e.errorKind()))
                                busy = false
                            }
                        }
                    }
                ) { Text(stringResource(R.string.acc_delete_confirm), color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = {
                TextButton(enabled = !busy, onClick = { askDelete = false; password = "" }) {
                    Text(stringResource(R.string.cancel))
                }
            }
        )
    }
}

/** المساعدة: معلومات التطبيق والإصدار. */
@Composable
fun HelpScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val version = remember {
        runCatching { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName }.getOrNull().orEmpty()
    }
    Column(Modifier.fillMaxSize()) {
        SubTopBar(stringResource(R.string.set_help), onBack)
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
            SettingRow(Icons.Outlined.Info, R.string.help_about, R.string.help_about_hint)
            SettingRow(Icons.Outlined.Info, R.string.help_version, R.string.help_version_hint)
            Text(
                "v$version",
                color = MaterialTheme.colorScheme.primary, fontSize = 14.sp,
                modifier = Modifier.padding(start = 60.dp, end = 18.dp, bottom = 10.dp)
            )
            Text(
                stringResource(R.string.help_roadmap),
                color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp,
                modifier = Modifier.padding(horizontal = 18.dp, vertical = 12.dp)
            )
        }
    }
}
